/* Save to Substack (v0.6.24, Anna 2026-10-12): the Stackyard's bookmark opens the post in a quiet
   background tab with #stackyard-save. Here, on Substack's own page, we use Substack's own Save,
   the same as a click, wait for its "Post saved" toast, and report back. No private API calls:
   if Substack moves or renames Save, the Stackyard says so instead of failing silently.

   What the real pages look like (Anna's screenshots + inspects, 2026-10-12):
   - Feed/inbox cards: <button aria-label="Save" title="Save"> holding svg.lucide-bookmark; once saved
     the svg gets an "activeSave-…" class (orange).
   - The reader (substack.com/home/post/p-…): no bookmark on the page. Save lives in the "…" menu,
     with a bookmark icon and the keyboard shortcut S.
   Order tried: a visible bookmark button → the S shortcut → the "…" menu's Save item. */
(() => {
  if (!location.hash.includes("stackyard-save")) return;
  const HOST = 'button,[role="button"],[role="menuitem"],a[role="button"]';
  const OUTSIDE = 'nav,aside,header,[role="navigation"],[role="tablist"],[role="tab"]';
  const ICON = 'svg.lucide-bookmark, path[d^="m19 21-7-4-7 4V5"]';
  const attrs = (el) => `${el.getAttribute("aria-label") || ""} ${el.getAttribute("title") || ""}`.trim();
  const visible = (el) => el.offsetParent !== null;
  const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const report = (result) => chrome.runtime.sendMessage({ type: "stackyard-save-result", url: location.href.split("#")[0], ...result });

  const toasts = () => [...document.querySelectorAll("div,span,p")]
    .map((el) => el.children.length ? "" : el.textContent.trim())
    .filter((t) => /^post (saved|unsaved|removed)|removed from saved/i.test(t));
  // Toasts in the order they appear; the newest one is Substack's current answer.
  const heard = [];
  new MutationObserver(() => {
    for (const t of toasts()) if (heard[heard.length - 1] !== t) heard.push(t);
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  const toastSaid = () => {
    const last = heard[heard.length - 1] || "";
    if (/unsaved|removed/i.test(last)) return "unsaved";
    if (/saved/i.test(last)) return "saved";
    return "";
  };
  // Wait for Substack's answer; if the action UN-saved (it was already saved), undo once.
  async function confirm(again, timeout = 3000) {
    const start = Date.now();
    let undone = false;
    while (Date.now() - start < timeout) {
      const said = toastSaid();
      if (said === "saved") {
        const count = heard.length;
        await wait(1000);
        if (toastSaid() === "saved") return { ok: true, already: undone, heard: heard.slice(-3) };
        if (heard.length !== count) continue;
      }
      if (said === "unsaved" && !undone) { undone = true; await wait(400); again(); }
      await wait(120);
    }
    return null;
  }

  const bookmarkButton = () => [...document.querySelectorAll(ICON)]
    .map((icon) => icon.closest(HOST)).find((el) => el && visible(el) && !el.closest(OUTSIDE) && el.getAttribute("role") !== "menuitem");
  const isActive = (el) => [...el.querySelectorAll("svg")].some((svg) => /\bactiveSave/i.test(svg.getAttribute("class") || ""));
  const pressS = () => {
    // keydown only. v0.6.29 sent keydown + keyup; if Substack toggles on both, a new post saved and
    // then UN-saved (Anna: "the actual save isn't working"), while an already-saved post looked fine.
    const event = new KeyboardEvent("keydown", { key: "s", code: "KeyS", keyCode: 83, which: 83, bubbles: true, cancelable: true });
    (document.activeElement && document.activeElement !== document.documentElement ? document.activeElement : document.body).dispatchEvent(event);
  };
  const moreButton = () => [...document.querySelectorAll('button,[role="button"]')].find((el) => visible(el) && !el.closest(OUTSIDE) &&
    (/^(more|more options|options|menu|post options)$/i.test(attrs(el)) || /^(\.\.\.|…)$/.test(el.textContent.trim()) ||
     el.querySelector("svg.lucide-ellipsis, svg.lucide-more-horizontal")));
  const menuSave = () => [...document.querySelectorAll('[role="menuitem"],button,a,div')]
    .find((el) => visible(el) && el.querySelector(ICON) && /^\s*save/i.test(el.textContent) && !/saved/i.test(el.textContent) && el.textContent.trim().length < 20);

  (async () => {
    // Let the page finish drawing (the reader builds itself after load).
    for (let i = 0; i < 25 && !bookmarkButton() && !moreButton(); i++) await wait(120);

    const button = bookmarkButton();
    if (button) {
      if (isActive(button)) return report({ ok: true, already: true, how: "button" });
      button.click();
      const result = await confirm(() => button.click());
      if (result || isActive(button)) return report({ ...(result || { ok: true, already: false }), how: "button" });
    }

    pressS();
    const byKey = await confirm(pressS, 1500);
    if (byKey) return report({ ...byKey, how: "shortcut" });

    const more = moreButton();
    if (more) {
      more.click();
      for (let i = 0; i < 15 && !menuSave(); i++) await wait(100);
      const item = menuSave();
      if (item) {
        item.click();
        const byMenu = await confirm(async () => { more.click(); await wait(300); menuSave()?.click(); });
        if (byMenu) return report({ ...byMenu, how: "menu" });
        return report({ ok: false, reason: "menu-not-confirmed" });
      }
    }
    const labels = [...document.querySelectorAll(HOST)].filter(visible).map((el) => attrs(el) || el.textContent.trim()).filter(Boolean).slice(0, 25);
    report({ ok: false, reason: "no-save-found", labels });
  })();
})();
