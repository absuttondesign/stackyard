(() => {
  const U = globalThis.SubstackVillages;
  const $ = (id) => document.getElementById(id);
  const PER_PUBLICATION = 8;
  const CONCURRENCY = 6;
  const DAY = 86400000;
  let settings, feed;
  let tab = "all";      // "all" or a village's source host
  let range = 30;       // days; 0 = everything fetched
  let listsChecked = false;   // re-read the village lists at most once per page load
  let kind = "posts";   // "posts" | "notes" | "both" — Notes and posts stay separable (Anna, 2026-09-29)
  const NOTE_BODY_MAX = 1200;

  function setStatus(message, kind = "") {
    $("status").textContent = message;
    $("status").className = `status ${kind}`;
  }

  const enabledSources = () => (settings.sources || []).filter((s) => s.enabled);

  function activeRecommendations() {
    return U.villageRecommendations(settings);
  }

  // Which villages a post belongs to. Posts fetched by this version carry it; older cached posts
  // are matched back through their publication's host.
  let hostToSources = new Map();
  function indexRecommendations() {
    hostToSources = new Map();
    for (const item of U.villageRecommendations(settings, false)) {
      for (const host of item.hosts || [item.host]) hostToSources.set(host, item.sources || [item.source]);
    }
  }
  const sourcesOf = (post) => post.sources || hostToSources.get(U.hostname(post.url)) || [];

  // ── color ────────────────────────────────────────────────────────────
  function rgb(hex) {
    const h = hex.replace("#", "");
    const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
    return [0, 2, 4].map((i) => parseInt(full.slice(i, i + 2), 16));
  }
  function luminance(hex) {
    const [r, g, b] = rgb(hex).map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }
  function mix(hex, withHex, amount) {
    const a = rgb(hex), b = rgb(withHex);
    return `#${a.map((v, i) => Math.round(v * amount + b[i] * (1 - amount)).toString(16).padStart(2, "0")).join("")}`;
  }
  const themeOf = (host) => enabledSources().find((s) => U.hostname(s.url) === host)?.theme || null;
  const accentOf = (host) => U.safeColor(themeOf(host)?.accent) || "#8A847C";

  function applyTheme() {
    // A village's page is its masthead (Anna, 2026-09-29): the publication's page color, its own
    // wordmark, its heading font for titles, and its accent as a stripe and on the active tab.
    // "All villages" stays Carrierfile Ink.
    const root = document.documentElement.style;
    const source = enabledSources().find((s) => U.hostname(s.url) === tab);
    const theme = source?.theme;
    const accent = U.safeColor(theme?.accent);
    const band = document.querySelector(".band");
    band.classList.toggle("masthead", Boolean(source && accent));
    if (!source || !accent) {
      for (const name of ["--v-accent", "--v-bg", "--v-page", "--v-head-font"]) root.removeProperty(name);
    } else {
      const page = U.safeColor(theme.pageColor) || "#ffffff";
      root.setProperty("--v-accent", accent);
      // In dark mode the page stays dark; the village keeps its wordmark, font and accent stripe.
      if (matchMedia("(prefers-color-scheme: dark)").matches) { root.removeProperty("--v-page"); root.removeProperty("--v-bg"); }
      else {
        root.setProperty("--v-page", page);
        root.setProperty("--v-bg", page.toLowerCase() === "#ffffff" ? "#ffffff" : mix(page, "#ffffff", 0.5));
      }
    }
    const font = source && /^[A-Za-z0-9 ]{1,60}$/.test(theme?.headingFont || "") ? theme.headingFont : "";
    if (font) {
      root.setProperty("--v-head-font", `'${font}', var(--font-serif)`);
      // Substack's heading fonts are Google Fonts; load the one this village uses.
      const href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(font).replace(/%20/g, "+")}:wght@400;700&display=swap`;
      let link = document.getElementById("village-font");
      if (!link) { link = document.createElement("link"); link.id = "village-font"; link.rel = "stylesheet"; document.head.append(link); }
      if (link.href !== href) link.href = href;
    } else root.removeProperty("--v-head-font");
    // The feed is what each publication RECOMMENDS, not what it published (Anna, 2026-10-01):
    // Top line = the Stackyard lockup + "RECOMMENDED SUBSTACKS" (Anna, 2026-10-12: no "’s", and the
    // label sits beside the lockup so uneven publication logos don't drag it around). Below it, the
    // publication alone: its wordmark in a fixed-height slot, or its icon + name.
    const name = source ? U.displayName(source) : "";
    const wordmark = $("village-wordmark");
    const useWordmark = Boolean(source && theme?.wordmark);
    wordmark.hidden = !useWordmark;
    if (useWordmark && wordmark.getAttribute("src") !== theme.wordmark) {
      wordmark.src = theme.wordmark; wordmark.alt = name;
      wordmark.onerror = () => { wordmark.hidden = true; $("village-name").textContent = name; $("village-name").hidden = false; $("village-icon").hidden = !theme.icon; };
    }
    // With a wordmark, the wordmark carries the name and the text follows it.
    $("village-name").textContent = !source ? "All haystacks" : name;
    $("village-name").hidden = useWordmark;
    const icon = $("village-icon");
    icon.hidden = useWordmark || !(source && theme?.icon);
    if (!icon.hidden) icon.src = theme.icon;
    document.title = source ? `${U.haystackOf(name)} · Stackyard` : "Stackyard";
  }

  // ── rendering ────────────────────────────────────────────────────────
  function relative(iso) {
    const ms = Date.now() - Date.parse(iso);
    const hours = Math.floor(ms / 3600000);
    if (hours < 1) { const minutes = Math.floor(ms / 60000); return minutes < 2 ? "just now" : `${minutes}m ago`; }
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(ms / DAY);
    if (days === 1) return "yesterday";
    if (days < 30) return `${days}d ago`;
    return new Date(iso).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
  }

  const inRange = (post) => !range || Date.parse(post.date) >= Date.now() - range * DAY;

  function renderTabs(postsInRange) {
    const nav = $("tabs");
    nav.replaceChildren();
    const sources = enabledSources();
    nav.hidden = sources.length < 2;
    const make = (id, label, count, accent) => {
      const button = document.createElement("button");
      button.type = "button"; button.className = "tab"; button.setAttribute("role", "tab");
      button.setAttribute("aria-selected", String(tab === id));
      if (accent) { const dot = document.createElement("span"); dot.className = "dot"; dot.style.background = accent; button.append(dot); }
      const n = document.createElement("span"); n.className = "n"; n.textContent = String(count);
      button.append(document.createTextNode(label + " "), n);
      button.addEventListener("click", () => { tab = id; chrome.storage.local.set({ villageTab: tab }); render(); });
      nav.append(button);
    };
    make("all", "All", postsInRange.length, null);
    for (const source of sources) {
      const host = U.hostname(source.url);
      make(host, U.displayName(source), postsInRange.filter((p) => sourcesOf(p).includes(host)).length, accentOf(host));
    }
  }

  // No Subscribe button (v0.6.53, Dinah via Anna): Stackyard can't tell whether the reader already
  // subscribes, so it only confused people.

  // Save to Substack (v0.6.24, Anna 2026-10-12: one Saved list, Substack's). Only on her click:
  // open the post in a background tab, where save.js presses Substack's own Save button and reports
  // back. No private API. If it can't confirm, the tab comes forward so she can save it by hand.
  const BOOKMARK = '<svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true"><path d="M6 3h12v18l-6-4.5L6 21z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>';
  let savedPosts = {};
  function saveButton(post) {
    const button = document.createElement("button"); button.type = "button"; button.className = "save";
    button.innerHTML = BOOKMARK;
    const saved = Boolean(savedPosts[post.url]);
    button.dataset.state = saved ? "saved" : "";
    button.title = saved ? "Saved to Substack" : "Save to your Substack Saved list";
    button.setAttribute("aria-label", button.title);
    button.addEventListener("click", () => saveToSubstack(post, button));
    return button;
  }
  async function saveToSubstack(post, button) {
    if (button.dataset.state === "busy") return;
    button.dataset.state = "busy"; button.title = "Saving to Substack…";
    // Substack's reader shows the bookmark as a plain icon; it needs the post's number. Older saved
    // feeds don't carry it, so ask the publication's public post API for it (a read, like the archive).
    let id = post.id;
    if (!id) {
      try {
        const url = new URL(post.url), slug = url.pathname.match(/\/p\/([^/?#]+)/)?.[1];
        if (slug) { const r = await fetch(`${url.origin}/api/v1/posts/${slug}`, { credentials: "omit" }); if (r.ok) id = (await r.json())?.id || null; }
      } catch {}
    }
    const target = id ? `https://substack.com/home/post/p-${id}` : post.url;
    const opened = await chrome.tabs.create({ url: `${target}#stackyard-save`, active: false });
    const result = await new Promise((resolve) => {
      const timer = setTimeout(() => { chrome.runtime.onMessage.removeListener(listen); resolve({ ok: false, reason: "timeout" }); }, 15000);
      function listen(message, sender) {
        if (message?.type !== "stackyard-save-result" || sender.tab?.id !== opened.id) return;
        clearTimeout(timer); chrome.runtime.onMessage.removeListener(listen); resolve(message);
      }
      chrome.runtime.onMessage.addListener(listen);
    });
    console.info("Stackyard save", result);
    if (result.ok) {
      chrome.tabs.remove(opened.id).catch(() => {});
      savedPosts = { ...savedPosts, [post.url]: new Date().toISOString() };
      chrome.storage.local.set({ savedToSubstack: savedPosts });
      button.dataset.state = "saved"; button.title = "Saved to Substack"; button.setAttribute("aria-label", button.title);
      $("status").textContent = result.already ? "Already in your Substack Saved list." : "Saved to your Substack Saved list.";
    } else {
      // Don't pull her away from the Stackyard (Anna, 2026-10-12): close the tab, say so, offer a link.
      chrome.tabs.remove(opened.id).catch(() => {});
      console.warn("Stackyard save failed", result);
      button.dataset.state = "error"; button.title = "Couldn't save this one. Open the post to save it there.";
      const status = $("status"); status.textContent = "Couldn't save that one automatically. ";
      const open = document.createElement("a"); open.href = post.url; open.target = "_blank"; open.rel = "noopener"; open.textContent = "Open the post to save it";
      status.append(open);
    }
  }

  function postItem(post) {
    const villages = sourcesOf(post).filter((host) => enabledSources().some((s) => U.hostname(s.url) === host));
    const item = document.createElement("li"); item.className = "post";
    if (tab === "all" && villages.length) item.style.setProperty("--post-accent", accentOf(villages[0]));
    const body = document.createElement("div");
    const meta = document.createElement("div"); meta.className = "meta";
    if (tab === "all" && villages.length) {
      const dots = document.createElement("span"); dots.className = "dots";
      dots.title = villages.length > 1 ? `In ${villages.length} haystacks` : "Haystack";
      for (const host of villages) { const dot = document.createElement("span"); dot.className = "dot"; dot.style.background = accentOf(host); dots.append(dot); }
      meta.append(dots);
    }
    const pub = document.createElement("span"); pub.className = "pub"; pub.textContent = post.publication;
    meta.append(pub);
    if (post.author && post.author !== post.publication) meta.append(document.createTextNode(`· ${post.author}`));
    const when = document.createElement("span");
    when.className = `when${Date.now() - Date.parse(post.date) < DAY ? " fresh" : ""}`;
    when.textContent = `· ${relative(post.date)}`; when.title = new Date(post.date).toLocaleString();
    meta.append(when);
    for (const [flag, label] of [[post.type === "podcast", "podcast"], [post.crossPost, "cross-post"]]) {
      if (flag) { const tag = document.createElement("span"); tag.className = "tag"; tag.textContent = label; meta.append(tag); }
    }
    const title = document.createElement("h2"); title.className = "title";
    const link = document.createElement("a"); link.href = post.url; link.target = "_blank"; link.rel = "noopener"; link.textContent = post.title;
    title.append(link);
    body.append(meta, title);
    if (post.subtitle) { const sub = document.createElement("p"); sub.className = "sub"; sub.textContent = post.subtitle; body.append(sub); }
    // Right column (Anna, 2026-10-12): the image, top-aligned with the publication line, and
    // Save tucked underneath it.
    const side = document.createElement("div"); side.className = "post-side";
    if (post.image) {
      const img = document.createElement("img"); img.src = post.image; img.alt = ""; img.loading = "lazy";
      img.addEventListener("error", () => { img.remove(); item.classList.add("no-image"); });
      side.append(img);
    }
    else item.classList.add("no-image");
    const actions = document.createElement("div"); actions.className = "actions";
    actions.append(saveButton(post));
    side.append(actions);
    item.append(body, side);
    return item;
  }

  function noteItem(note) {
    const villages = sourcesOf(note).filter((host) => enabledSources().some((s) => U.hostname(s.url) === host));
    const item = document.createElement("li"); item.className = "post note";
    if (tab === "all" && villages.length) item.style.setProperty("--post-accent", accentOf(villages[0]));
    const body = document.createElement("div");
    const meta = document.createElement("div"); meta.className = "meta";
    const tag = document.createElement("span"); tag.className = "tag note-tag"; tag.textContent = "note";
    const who = document.createElement("span"); who.className = "pub"; who.textContent = note.author || note.publication;
    meta.append(tag, who);
    if (note.publication && note.publication !== note.author) meta.append(document.createTextNode(`· ${note.publication}`));
    const when = document.createElement("a");
    when.className = `when${Date.now() - Date.parse(note.date) < DAY ? " fresh" : ""}`;
    when.href = note.url; when.target = "_blank"; when.rel = "noopener";
    when.textContent = `· ${relative(note.date)}`; when.title = `Open note · ${new Date(note.date).toLocaleString()}`;
    meta.append(when);
    const text = document.createElement("a"); text.className = "note-body";
    text.href = note.url; text.target = "_blank"; text.rel = "noopener"; text.textContent = note.body;
    body.append(meta, text);
    if (note.linkedTitle) {
      const linked = document.createElement("p"); linked.className = "linked";
      linked.textContent = `↳ ${note.linkedPublication ? `${note.linkedPublication}: ` : ""}${note.linkedTitle}`;
      body.append(linked);
    }
    item.append(body);
    if (note.image) {
      const img = document.createElement("img"); img.src = note.image; img.alt = ""; img.loading = "lazy";
      img.addEventListener("error", () => { img.remove(); item.classList.add("no-image"); });
      item.append(img);
    } else item.classList.add("no-image");
    return item;
  }

  function render() {
    if (tab !== "all" && !enabledSources().some((s) => U.hostname(s.url) === tab)) tab = "all";
    // One village ticked: the page is that village's, colors and all (Anna, 2026-09-29 — branding
    // only showed with several ticked, because the lone village fell back to "All").
    if (enabledSources().length === 1) tab = U.hostname(enabledSources()[0].url);
    applyTheme();
    for (const input of document.querySelectorAll('input[name="range"]')) input.checked = Number(input.value) === range;
    for (const input of document.querySelectorAll('input[name="kind"]')) input.checked = input.value === kind;
    const list = $("posts");
    list.replaceChildren();
    const empty = (text) => { const p = document.createElement("li"); p.className = "empty"; p.textContent = text; list.append(p); };
    const pool = [...(kind !== "notes" ? feed?.posts || [] : []), ...(kind !== "posts" ? feed?.notes || [] : [])];
    if (!pool.length) {
      renderTabs([]);
      empty(refreshing || !feed ? "Searching the haystacks…" : kind === "notes" && !feed.notes ? "Notes load on the next Refresh." : "Nothing yet. Try Refresh.");
      return;
    }
    const inRangeItems = pool.filter(inRange).sort((a, b) => Date.parse(b.date) - Date.parse(a.date));
    renderTabs(inRangeItems);
    const items = tab === "all" ? inRangeItems : inRangeItems.filter((p) => sourcesOf(p).includes(tab));
    for (const item of items) list.append(item.kind === "note" ? noteItem(item) : postItem(item));
    if (!items.length) empty("Nothing in this range. Try a wider one.");
    const nPosts = items.filter((i) => i.kind !== "note").length, nNotes = items.length - nPosts;
    const counts = [kind !== "notes" && `${nPosts} posts`, kind !== "posts" && `${nNotes} notes`].filter(Boolean).join(" · ");
    const skipped = (feed.skipped?.length || 0) + (kind !== "posts" ? feed.notesSkipped || 0 : 0);
    const age = feed.fetchedAt ? relative(feed.fetchedAt).replace(" ago", "") : "";
    setStatus(`${counts}${age ? ` · fetched ${age}${age === "just now" ? "" : " ago"}` : ""}${skipped ? ` · ${skipped} unreadable` : ""}`,
      skipped ? "busy" : "");
    renderAllowButton();
  }

  // ── custom domains ───────────────────────────────────────────────────
  function customDomainsSkipped() {
    return [...new Set((feed?.skipped || []).map((item) => item.customDomain).filter(Boolean))];
  }

  function renderAllowButton() {
    const domains = customDomainsSkipped();
    const button = $("allow-custom");
    button.hidden = !domains.length;
    if (domains.length) {
      button.textContent = `Allow ${domains.length} custom domain${domains.length === 1 ? "" : "s"} →`;
      button.title = domains.join(", ");
    }
  }

  // A custom domain often redirects between its bare and www forms (aiparenttech.com →
  // www.aiparenttech.com, Anna 2026-10-01), so permission covers both.
  const domainOrigins = (d) => { const bare = d.replace(/^www\./, ""); return [`https://${bare}/*`, `https://www.${bare}/*`]; };

  async function allowCustomDomains() {
    // Must run from a click: Chrome shows its own permission prompt for exactly these sites.
    const domains = customDomainsSkipped();
    if (!domains.length) return;
    const granted = await chrome.permissions.request({ origins: domains.flatMap(domainOrigins) });
    if (granted) await refresh();
    else setStatus("Not allowed. Those publications stay skipped.", "error");
  }

  // ── fetching ─────────────────────────────────────────────────────────
  async function fetchPublication(entry) {
    // Prefer the .substack.com host: the extension only has permission for substack.com.
    const host = (entry.hosts || [entry.host]).find((h) => h.endsWith(".substack.com")) || entry.host;
    const custom = (entry.hosts || []).find((h) => !h.endsWith(".substack.com"));
    const path = `/api/v1/archive?sort=new&offset=0&limit=${PER_PUBLICATION}`;
    // redirect: "manual" — a publication on a custom domain redirects off substack.com, which the
    // extension only has permission for once Anna grants it; following it blind logs a CORS error.
    let response = await fetch(`https://${host}${path}`, { credentials: "omit", redirect: "manual" });
    if (response.type === "opaqueredirect") {
      if (!custom || !(await chrome.permissions.contains({ origins: domainOrigins(custom) }))) {
        const error = new Error("custom domain"); error.customDomain = custom; throw error;
      }
      response = await fetch(`https://${custom}${path}`, { credentials: "omit" });
    }
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const items = await response.json();
    if (!Array.isArray(items)) throw new Error("Unexpected archive response.");
    return items.filter((post) => post.canonical_url && post.post_date && post.title).map((post) => ({
      kind: "post", id: post.id || null, title: post.title, subtitle: post.subtitle || "", url: post.canonical_url, date: post.post_date,
      type: post.type || "newsletter", crossPost: Boolean(post.restacked_post_slug),
      image: post.cover_image || "", publication: entry.publication || host,
      author: (post.publishedBylines || []).map((b) => b.name).filter(Boolean).join(", ") || entry.author || "",
      sources: entry.sources || [entry.source]
    }));
  }

  async function fetchNotes(entry) {
    // The writer's public profile feed on substack.com: their latest Notes, newest first.
    const response = await fetch(`https://substack.com/api/v1/reader/feed/profile/${entry.authorId}`, { credentials: "omit" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    return (data?.items || []).map((item) => U.noteFromItem(item, entry)).filter(Boolean)
      .map((note) => ({ ...note, body: note.body.length > NOTE_BODY_MAX ? `${note.body.slice(0, NOTE_BODY_MAX)}…` : note.body }));
  }

  async function pool(items, task, label) {
    let done = 0;
    const queue = [...items];
    const worker = async () => {
      while (queue.length) {
        const item = queue.shift();
        await task(item);
        done++;
        setStatus(`${label}… ${done} of ${items.length}`, "busy");
      }
    };
    await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  }

  async function ensureAuthorIds() {
    // Notes are fetched by the writer's user id, which lists refreshed before Notes existed lack.
    // Re-read the lists once (the same public pages the popup reads) and save them.
    if (listsChecked || activeRecommendations().every((entry) => entry.authorId)) return;
    listsChecked = true;
    setStatus("Updating the haystacks for Notes…", "busy");
    const sources = enabledSources();
    const { entries, errors, extras } = await U.fetchVillageLists(sources);
    if (errors.length || !entries.length) return;
    const keep = (settings.recommendations || []).filter((item) =>
      !(item.sources || [item.source]).some((s) => sources.some((src) => U.hostname(src.url) === s)));
    settings.recommendations = U.uniqueRecommendations([...keep, ...entries]);
    settings.sources = (settings.sources || []).map((s) => extras.has(s.url) ? { ...s, ...extras.get(s.url) } : s);
    settings.refreshedAt = new Date().toISOString();
    await chrome.storage.local.set({ recommendations: settings.recommendations, sources: settings.sources, refreshedAt: settings.refreshedAt });
    indexRecommendations();
  }

  async function refresh() {
    if (!activeRecommendations().length) { setStatus("No haystacks on. Open Stackyard from the toolbar, tick one and click Refresh.", "error"); return; }
    const button = $("refresh"); button.disabled = true; refreshing = true;
    if (!feed?.posts?.length && !feed?.notes?.length) render();   // empty list says "Reading…" while it works
    try { await ensureAuthorIds(); } catch { /* Notes for writers without an id are skipped below */ }
    const entries = activeRecommendations();
    const posts = [], skipped = [], notes = [];
    let notesSkipped = 0;
    await pool(entries, async (entry) => {
      try { posts.push(...await fetchPublication(entry)); }
      catch (error) { skipped.push({ host: entry.host, error: error.message, customDomain: error.customDomain || null }); }
    }, "Reading posts");
    // One request per writer, even when a writer has several publications in the villages.
    const writers = new Map();
    for (const entry of entries) {
      if (!entry.authorId) continue;
      const old = writers.get(entry.authorId);
      if (old) old.sources = [...new Set([...old.sources, ...(entry.sources || [entry.source])])];
      else writers.set(entry.authorId, { ...entry, sources: [...(entry.sources || [entry.source])] });
    }
    await pool([...writers.values()], async (entry) => {
      try { notes.push(...await fetchNotes(entry)); } catch { notesSkipped++; }
    }, "Reading Notes");
    const byUrl = new Map();
    for (const post of posts) {
      const old = byUrl.get(post.url);
      if (old) old.sources = [...new Set([...old.sources, ...post.sources])];
      else byUrl.set(post.url, post);
    }
    const unique = [...byUrl.values()].sort((a, b) => Date.parse(b.date) - Date.parse(a.date));
    const noteByUrl = new Map(notes.map((note) => [note.url, note]));
    const uniqueNotes = [...noteByUrl.values()].sort((a, b) => Date.parse(b.date) - Date.parse(a.date));
    feed = { fetchedAt: new Date().toISOString(), posts: unique, notes: uniqueNotes, skipped, notesSkipped };
    await chrome.storage.local.set({ villageFeed: feed });
    button.disabled = false; refreshing = false;
    render();
  }


  async function loadMissingThemes() {
    // Villages set up before themes existed get their colors read once, from the same public
    // recommendations page the popup reads.
    const missing = enabledSources().filter((s) => !s.theme || s.theme.version !== 2 || U.autoNamed(s));
    if (!missing.length) return;
    const themes = new Map();
    await Promise.all(missing.map(async (source) => {
      try {
        const response = await fetch(source.url, { credentials: "omit" });
        if (!response.ok) return;
        const html = await response.text();
        const realName = U.publicationName(html);
        themes.set(source.url, { theme: U.parseTheme(html), ...(U.autoNamed(source) && realName ? { name: `${realName} Village` } : {}) });
      } catch { /* colors are optional; the page stays Ink */ }
    }));
    if (!themes.size) return;
    const latest = (await chrome.storage.local.get("sources")).sources || settings.sources;
    settings.sources = latest.map((s) => themes.get(s.url) ? { ...s, ...themes.get(s.url) } : s);
    await chrome.storage.local.set({ sources: settings.sources });
    render();
  }

  $("refresh").addEventListener("click", refresh);
  $("allow-custom").addEventListener("click", allowCustomDomains);
  for (const input of document.querySelectorAll('input[name="kind"]')) {
    input.addEventListener("change", () => { kind = input.value; chrome.storage.local.set({ villageKind: kind }); render(); });
  }
  for (const input of document.querySelectorAll('input[name="range"]')) {
    input.addEventListener("change", () => { range = Number(input.value); chrome.storage.local.set({ villageRange: range }); render(); });
  }
  // Exact Substack nav (v0.6.34, Anna: "exactly match the substack nav"): nav.js copies Substack's
  // real left nav (links, labels, icons, avatar) into storage on each substack.com visit; draw that,
  // plus the Stackyard item where nav.js adds it on Substack. No copy yet → the built-in fallback.
  const cleanSvg = U.cleanSvg;
  // Substack draws most nav icons from shapes defined elsewhere on its page (and fills them by its
  // own CSS), so a copied <svg> can come out blank or black here (Anna, 2026-10-12: "variation in
  // left nav"). Known items get the same Lucide icons Substack uses, drawn here; the copy still
  // decides which items, in what order, with which links and her avatar.
  const LUCIDE = (paths) => `<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
  const NAV_ICONS = [
    [/^substack$|logo/i, '<svg viewBox="0 0 24 24" width="30" height="30" fill="#FF6719"><path d="M22.539 8.242H1.46V5.406h21.08v2.836zM1.46 10.812V24L12 18.11 22.54 24V10.812H1.46zM22.54 0H1.46v2.836h21.08V0z"/></svg>'],
    [/home/i, LUCIDE('<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>')],
    [/subscriptions|inbox/i, LUCIDE('<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>')],
    [/chat|message/i, LUCIDE('<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>')],
    [/activity|notification/i, LUCIDE('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>')],
    [/explore|search/i, LUCIDE('<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>')],
    [/dashboard|publish/i, LUCIDE('<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M8 17v-3M12 17V9M16 17v-6"/>')],
    [/create|new post|write/i, LUCIDE('<path d="M12 5v14M5 12h14"/>')],
    [/more|menu/i, LUCIDE('<path d="M4 6h16M4 12h16M4 18h16"/>')]
  ];
  const iconFor = (item) => NAV_ICONS.find(([test]) => test.test(`${item.label} ${item.href.replace(/^https:\/\/substack\.com\/home\/?$/, "")}`))?.[1] || "";

  // Substack's Create menu, as Anna's screenshot shows it. Each choice goes to Substack and presses
  // Create → that item there (nav.js), so it opens exactly what Substack would.
  const CREATE_ITEMS = [
    ["Note", '<path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/>'],
    ["Article", '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4M10 9H8M16 13H8M16 17H8"/>'],
    null,
    ["Video", '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="m9 8 6 4-6 4Z"/>'],
    ["Podcast", '<path d="M12 19v3M19 10v2a7 7 0 0 1-14 0v-2"/><rect x="9" y="2" width="6" height="13" rx="3"/>'],
    ["Live", '<path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5M19.1 4.9C23 8.8 23 15.1 19.1 19"/><circle cx="12" cy="12" r="2"/>'],
    ["Recording studio", '<path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"/><rect x="2" y="6" width="14" height="12" rx="2"/>']
  ];
  const createMenu = document.createElement("div");
  createMenu.className = "sy-create-menu"; createMenu.hidden = true; createMenu.setAttribute("role", "menu");
  for (const entry of CREATE_ITEMS) {
    if (!entry) { const line = document.createElement("hr"); createMenu.append(line); continue; }
    const [name, paths] = entry;
    const a = document.createElement("a"); a.setAttribute("role", "menuitem");
    a.href = `https://substack.com/home#stackyard-open=Create&pick=${encodeURIComponent(name)}`;
    const icon = cleanSvg(`<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`);
    if (icon) a.append(icon);
    a.append(name); createMenu.append(a);
  }
  document.addEventListener("click", (event) => {
    if (createMenu.hidden || createMenu.contains(event.target) || event.target.closest?.(".sy-create")) return;
    createMenu.hidden = true; document.querySelector(".sy-create")?.setAttribute("aria-expanded", "false");
  });

  function drawSubstackNav(saved) {
    const items = saved?.items;
    if (!Array.isArray(items) || !items.length) return;
    const rail = document.querySelector(".sy-rail"), menu = document.getElementById("sy-more-menu");
    rail.replaceChildren();
    rail.classList.add("is-copy");
    // Substack's own numbers, when the copy has them (v0.6.39).
    if (saved.width > 40 && saved.width < 200) { rail.style.width = `${saved.width}px`; document.body.style.setProperty("--sy-rail-width", `${saved.width}px`); }
    if (saved.iconColor) rail.style.setProperty("--sy-icon", saved.iconColor);
    if (saved.iconOpacity > 0 && saved.iconOpacity < 1) rail.style.setProperty("--sy-icon-opacity", saved.iconOpacity);
    const orange = items.find((item) => item.accentColor)?.accentColor;
    if (orange) rail.style.setProperty("--sy-orange", orange);
    const logo = items[0]?.logoColor;
    if (logo && logo !== "none" && !/rgba\(0, 0, 0, 0\)/.test(logo)) rail.style.setProperty("--sy-logo", logo);

    let placed = false;
    const stackyard = () => {
      const a = document.createElement("a"); a.href = "village.html"; a.title = "Stackyard"; a.setAttribute("aria-label", "Stackyard");
      a.setAttribute("aria-current", "page"); a.className = "is-here";
      const img = document.createElement("img"); img.src = "icons/logo.svg"; img.alt = ""; img.className = "sy-here-icon"; a.append(img);
      return a;
    };
    items.forEach((item, index) => {
      // More: Substack's last item, a button with the ≡ icon; its label isn't always "More".
      const isMore = !item.href && !item.accent && (/more|menu/i.test(item.label) || index === items.length - 1);
      // Create opens Substack's own little menu right here (v0.6.44, Anna: it "opens from any page").
      const isCreate = item.accent && !item.href;
      const el = document.createElement(item.href || (!isMore && !isCreate) ? "a" : "button");
      if (isCreate) {
        el.type = "button"; el.classList.add("sy-create"); el.setAttribute("aria-expanded", "false");
        el.addEventListener("click", (event) => {
          event.stopImmediatePropagation();
          const open = el.getAttribute("aria-expanded") !== "true";
          el.setAttribute("aria-expanded", String(open));
          createMenu.hidden = !open;
          if (open) createMenu.style.top = `${el.getBoundingClientRect().bottom + 8}px`;
        });
      }
      // Dashboard and Create are buttons on Substack, not links (Anna, v0.6.41: both landed on Home).
      // Send them to Substack with a note naming the button; nav.js presses that button there.
      if (el.tagName === "A") el.href = item.href || `https://substack.com/home#stackyard-open=${encodeURIComponent(item.label)}`;
      else if (isCreate) { /* set up above */ }
      else { el.type = "button"; el.className = "sy-more"; el.setAttribute("aria-expanded", "false"); el.setAttribute("aria-controls", "sy-more-menu"); }
      el.title = item.label || ""; if (item.label) el.setAttribute("aria-label", item.label);
      if (index === 0) el.classList.add("sy-brand");
      if (item.accent) el.classList.add("sy-accent");
      // Substack's own icon (made standalone by nav.js, v0.6.38) wins; the Lucide set is the backup.
      // The logo stays the orange mark drawn here.
      const backup = index === 0 && !item.img ? NAV_ICONS[0][1] : item.img ? "" : isMore ? NAV_ICONS[NAV_ICONS.length - 1][1] : iconFor(item);
      // The logo too (v0.6.39: Anna, "our substack logo is slightly squished"): Substack's own, at its
      // own size and color.
      // A slot that holds the logo's svg (old copies, see nav.js) falls back to its backup icon.
      const own = item.svg && !(index > 0 && item.svg === items[0]?.svg) ? cleanSvg(item.svg) : null;
      const icon = own || (backup ? cleanSvg(backup) : null);
      if (icon && !own) icon.classList.add("sy-backup");
      if (icon) el.append(icon);
      else if (item.img) { const img = document.createElement("img"); img.src = item.img; img.alt = ""; img.className = "sy-avatar"; el.append(img); }
      if (Number.isFinite(item.y)) { el.dataset.y = item.y; el.dataset.bottom = item.bottom; }
      rail.append(el);
      if (!placed && /search|explore/i.test(`${item.label} ${item.href}`)) { rail.append(stackyard()); placed = true; }
    });
    if (!placed) rail.insertBefore(stackyard(), rail.children[1] || null);
    if (menu) rail.append(menu);
    if (createMenu.childElementCount) document.body.append(createMenu);
    // Place each item where Substack has it: items carry their centre (y) from the rail top; the
    // Stackyard item takes the slot after Explore, one step down, and pushes the rest by one step
    // (the same thing nav.js does on Substack). More stays measured from the bottom.
    const kids = [...rail.children].filter((el) => el !== menu);
    const ys = kids.map((el) => Number(el.dataset.y)).filter(Number.isFinite);
    if (ys.length > 3) {
      const steps = ys.slice(1).map((y, i) => y - ys[i]).filter((d) => d > 20).sort((a, b) => a - b);
      const step = steps[Math.floor(steps.length / 2)] || 56;
      // Substack's measurements already include our Stackyard item when nav.js recorded where it sat;
      // only an older copy without that needs the one-step push.
      const knownSpot = Number.isFinite(saved.stackyardY);
      let shift = 0;
      rail.classList.add("is-measured");
      for (const el of kids) {
        if (!el.dataset.y && el.classList.contains("is-here")) {
          const prev = el.previousElementSibling;
          if (knownSpot) el.style.top = `${saved.stackyardY}px`;
          else { shift = step; el.style.top = `${Number(prev?.dataset.y || 0) + step}px`; }
          continue;
        }
        if (el.classList.contains("sy-more") && el.dataset.bottom) { el.style.bottom = `${el.dataset.bottom}px`; continue; }
        if (el.dataset.y) el.style.top = `${Number(el.dataset.y) + shift}px`;
      }
    }
  }

  // The popup's "Hide the side menu" applies here too (v0.6.43): unticked = pinned like Substack's,
  // ticked = the edge drawer. The page opens pinned (village.html) and keeps the last choice in its own
  // storage, so neither choice shows the other for a moment first; chrome.storage has the final say.
  const RAIL_CACHE = "stackyard-hide-rail";
  function pinRail(hidden) {
    document.body.classList.toggle("rail-pinned", !hidden);
    try { localStorage.setItem(RAIL_CACHE, hidden ? "1" : "0"); } catch {}
  }
  try { if (localStorage.getItem(RAIL_CACHE) === "1") document.body.classList.remove("rail-pinned"); } catch {}
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "hideRail" in changes) pinRail(changes.hideRail.newValue);
  });

  // Drawer "More" menu (Settings, Support): toggles on click, closes on any click elsewhere.
  let more = document.querySelector(".sy-more"), moreMenu = document.getElementById("sy-more-menu");
  document.addEventListener("click", (event) => {
    if (!event.target.closest?.(".sy-more")) return;
    more = event.target.closest(".sy-more");
    event.stopImmediatePropagation();
    const open = more.getAttribute("aria-expanded") !== "true";
    more.setAttribute("aria-expanded", String(open)); moreMenu.hidden = !open;
  });
  document.addEventListener("click", (event) => {
    if (more?.getAttribute("aria-expanded") === "true" && !moreMenu.contains(event.target) && !event.target.closest?.(".sy-more")) { more.setAttribute("aria-expanded", "false"); moreMenu.hidden = true; }
  });

  chrome.storage.local.get(null).then((stored) => {
    settings = { ...U.DEFAULTS, ...stored };
    drawSubstackNav(stored.substackNav);
    U.applySubstackOrange(stored.substackNav);
    pinRail(stored.hideRail);
    feed = stored.villageFeed || null;
    savedPosts = stored.savedToSubstack || {};
    if (typeof stored.villageTab === "string") tab = stored.villageTab;
    if (Number.isFinite(stored.villageRange)) range = stored.villageRange;
    if (["posts", "notes", "both"].includes(stored.villageKind)) kind = stored.villageKind;
    indexRecommendations();
    render();
    document.body.classList.remove("is-loading");
    loadMissingThemes();
    if (isStale()) refresh();
  }).finally(() => document.body.classList.remove("is-loading"));   // never leave the page invisible
  // The saved feed is a snapshot. Refetch on open, and when the tab comes back into view, once it
  // is more than 15 minutes old, so a post from ten minutes ago shows up without a click
  // (Anna, 2026-09-29).
  const STALE_MS = 15 * 60000;
  let refreshing = false;
  function isStale() { return !feed?.fetchedAt || !feed.notes || Date.now() - Date.parse(feed.fetchedAt) > STALE_MS; }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && settings && !refreshing && isStale()) refresh();
  });
})();
