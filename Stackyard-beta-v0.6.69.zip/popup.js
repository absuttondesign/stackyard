(() => {
  const U = globalThis.SubstackVillages;
  const $ = (id) => document.getElementById(id);
  let settings;

  let undoRemove = null;
  function setStatus(message, kind = "", action = "") {
    const status = $("status");
    status.textContent = message;
    status.className = `status ${kind}`;
    if (action && undoRemove) {
      const button = document.createElement("button"); button.type = "button"; button.className = "undo"; button.textContent = action;
      const run = undoRemove; undoRemove = null;
      button.addEventListener("click", run);
      status.append(" ", button);
    }
  }

  async function save(patch) {
    settings = { ...settings, ...patch };
    await chrome.storage.local.set(patch);
    render();
  }

  function countFor(source) {
    const host = U.hostname(source.url);
    return U.villageRecommendations({ sources: [source], recommendations: settings.recommendations }, false)
      .filter((item) => (item.sources || [item.source]).includes(host)).length;
  }

  function render() {
    // One switch: ON = haystacks only + newest first; OFF = Substack's feed as it is.
    // Storage keys are unchanged (enabled, newestFirst) and always move together.
    document.querySelector(`input[name="mode"][value="${settings.mode}"]`).checked = true;
    const on = settings.enabled;
    $("village-options").hidden = !on;
    $("power-hint").textContent = on ? "Showing your haystacks, newest first." : "Showing Substack's own feed.";
    $("enabled").checked = on;
    $("power").classList.toggle("is-on", on);
    $("power-state").textContent = on ? "ON" : "OFF";
    $("reposts").checked = settings.includeReposts;
    const focus = Boolean(settings.focusMode);
    $("focus").checked = focus;
    $("focus-power").classList.toggle("is-on", focus);
    $("focus-state").textContent = focus ? "ON" : "OFF";
    $("hide-rail").checked = Boolean(settings.hideRail);
    $("focus-hint").textContent = focus ? "Preserving your attention: no unread badges." : "Hide the unread badges that pull you in.";
    const list = $("sources");
    list.replaceChildren();
    for (const source of settings.sources) {
      const row = document.createElement("li");
      row.className = `source${source.enabled ? "" : " is-disabled"}`;
      const toggle = document.createElement("input"); toggle.type = "checkbox"; toggle.checked = source.enabled;
      toggle.className = "haystack-check";
      toggle.setAttribute("aria-label", `Use ${source.name}`);
      toggle.addEventListener("change", () => save({ sources: settings.sources.map((item) =>
        item.url === source.url ? { ...item, enabled: toggle.checked } : item) }));
      const dot = document.createElement("span"); dot.className = "dot";
      dot.style.background = U.safeColor(source.theme?.accent) || "var(--text-faint)";
      const name = document.createElement("span"); name.className = "name"; name.textContent = U.displayName(source); name.title = source.url;
      const count = document.createElement("span"); count.className = "count";
      const n = countFor(source); count.textContent = n ? String(n) : "–"; count.title = `${n} recommended publications`;
      const remove = document.createElement("button"); remove.type = "button"; remove.className = "remove"; remove.textContent = "×";
      remove.setAttribute("aria-label", `Remove ${source.name}`);
      remove.addEventListener("click", async () => {
        const before = settings.sources;
        await save({ sources: settings.sources.filter((item) => item.url !== source.url) });
        undoRemove = () => save({ sources: before });
        setStatus(`Removed ${source.name}.`, "busy", "Undo");
      });
      row.append(toggle, dot, name, count, remove); list.append(row);
    }
    // A failed refresh used to vanish when the popup closed, so a blank feed had no visible cause.
    if (settings.lastRefreshError) setStatus(`Not updated: ${settings.lastRefreshError}`, "error");
    else if (!settings.refreshedAt) setStatus("Loading the haystacks…", "busy");
    else setStatus(`${U.villageRecommendations(settings).length} publications · updated ${new Date(settings.refreshedAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`);
  }

  async function refresh() {
    const button = $("refresh"); button.disabled = true;
    setStatus("Reading recommendation lists…", "busy");
    // Every village, ticked or not: a village's count is its list, not whether it's in use today.
    // (Reading only ticked ones dropped the others' lists — counts fell to 1. Anna, 2026-09-29.)
    const { entries: all, errors, extras } = await U.fetchVillageLists(settings.sources);
    if (all.length && !errors.length) {
      const sources = settings.sources.map((item) => extras.has(item.url) ? { ...item, ...extras.get(item.url) } : item);
      await save({ sources, recommendations: U.uniqueRecommendations(all), refreshedAt: new Date().toISOString(), lastRefreshError: "" });
    } else if (errors.length) {
      // A partial fetch is not a refresh: keep the previous lists and say what failed (and keep
      // saying it next time the popup opens).
      await save({ lastRefreshError: errors.join(" · ") });
    } else setStatus("Add a haystack first.", "error");
    button.disabled = false;
  }

  $("enabled").addEventListener("change", (event) =>
    save({ enabled: event.target.checked, newestFirst: event.target.checked }));
  $("focus").addEventListener("change", (event) => save({ focusMode: event.target.checked }));
  $("hide-rail").addEventListener("change", (event) => save({ hideRail: event.target.checked }));
  $("reposts").addEventListener("change", (event) => save({ includeReposts: event.target.checked }));
  document.querySelectorAll('input[name="mode"]').forEach((input) =>
    input.addEventListener("change", () => save({ mode: input.value })));
  $("refresh").addEventListener("click", refresh);
  // The feedback form fills in the version, so reports say which build they came from.
  $("report-link").href += `?v=${encodeURIComponent(chrome.runtime.getManifest().version)}`;
  // Links in an extension popup don't open on their own; open the studio site in a new tab.
  document.querySelectorAll("a[data-open]").forEach((link) => link.addEventListener("click", (event) => {
    event.preventDefault(); chrome.tabs.create({ url: link.href });
  }));
  $("open-village").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("village.html") }));
  $("add-source").addEventListener("submit", async (event) => {
    event.preventDefault();
    try {
      const url = U.normalizeSourceUrl($("source-url").value);
      if (settings.sources.some((source) => source.url === url)) throw new Error("That source is already listed.");
      const name = `${new URL(url).hostname.split(".")[0].replace(/[-_]/g, " ")} Village`;
      await save({ sources: [...settings.sources, { name, url, enabled: true }] });
      $("source-url").value = "";
      await refresh();
    } catch (error) { setStatus(error.message, "error"); }
  });

  chrome.storage.local.get(null).then(async (stored) => {
    settings = { ...U.DEFAULTS, ...stored };
    U.applySubstackOrange(stored.substackNav);
    if (!stored.sources) await chrome.storage.local.set({ sources: settings.sources });
    // v0.4 let the two keys disagree (ON + Everything = sort only). One switch now: they match.
    if (settings.newestFirst !== settings.enabled) {
      settings.newestFirst = settings.enabled;
      await chrome.storage.local.set({ newestFirst: settings.enabled });
    }
    render();
    // First run (or a list over a week old): load the haystacks without waiting for a click.
    // Dinah's first install never got a Refresh, so the filter ran with no lists and hid the
    // whole feed ("0 found in 878 checked", 2026-10-10).
    const age = settings.refreshedAt ? Date.now() - Date.parse(settings.refreshedAt) : Infinity;
    if (settings.sources.length && !(age < 7 * 24 * 60 * 60 * 1000)) refresh();
  });
})();
