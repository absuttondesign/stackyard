(() => {
  const U = globalThis.SubstackVillages;
  const HIDDEN_CLASS = "substack-villages-hidden";
  const ACTIVE_CLASS = "substack-villages-active";   // on the feed while Villages only is on
  const SORTED_CLASS = "substack-villages-sorted";   // on the feed container while newest-first is on
  const SEEN_ATTR = "data-substack-villages-seen";   // on a card once this script has judged it
  const FIRST_BATCH = 10;      // the first reveal comes sooner (Dinah, 2026-10-01: "load time is really long")…
  const BATCH = 6;             // …then each later batch asks Substack for more until this many more match (small, Anna 10/10)…
  let autoloadCap = 600;    // …or this many cards are loaded, whichever comes first.
  const SETTLE_MS = 700;       // loading must be done this long before the panel fades out
  const STALL_MS = 12000;      // Substack sent nothing new for this long: stop searching instead of hanging
  let target = FIRST_BATCH;    // grows by BATCH when the reader scrolls near the end of what's shown
  let lastCardCount = 0, lastGrowthAt = Date.now();
  // A card's verdict is computed once it has fully rendered (it has a permalink), then reused, so a
  // like or a comment doesn't make every card on the page be re-judged (Dinah: likes felt slow).
  const SETTLED_ATTR = "data-sv-settled";
  let verdictVersion = 0;
  const verdicts = new WeakMap();
  let loading = false, loadingOffTimer = null, nudgeTimer = null;
  let firstBatch = true;       // the first batch is found behind a cover, then revealed at once
  let ended = false;           // a search ran out: stay stopped until the reader asks to keep digging
  let settings = null;
  let scheduled = null;
  let currentUrl = location.href;
  let lastFeedPath = location.pathname.replace(/\/$/, "");
  const originalOrders = new Map();
  let lastSortKey = "";
  let lastNudgedCount = -1;
  let endShownUntil = 0;
  const DATE_WAIT_MS = 1500;   // how long a new card may wait, invisible, for its date to render
  const firstSeen = new WeakMap();

  const style = document.createElement("style");
  style.textContent = `.${HIDDEN_CLASS}{display:none!important}` +
    `html[data-substack-villages="on"] [aria-label="Notes feed"],html[data-substack-villages-sort="on"] [aria-label="Notes feed"]{overflow-anchor:none}` +
    // Anything in the sorted container that is not a card (Substack's loading skeleton, spinners)
    // goes to the bottom the instant it appears, instead of popping in at the top with order 0
    // and jumping down on the next pass.
    `.${SORTED_CLASS}>:not([aria-label="Note"]):not([aria-label="Post"]){order:2147483000!important}` +
    // A freshly loaded card stays out of the page until this script has judged it, so a stranger's
    // note never flashes on screen before being hidden. display:none, not visibility:hidden: an
    // invisible card still takes up room, and a run of them left the screen blank while a batch
    // loaded (Anna, 2026-10-01, scrolling to the bottom).
    `html[data-substack-villages="on"]:not([data-sv-reader]) [aria-label="Note"]:not([${SEEN_ATTR}]),` +
    `html[data-substack-villages="on"]:not([data-sv-reader]) [aria-label="Post"]:not([${SEEN_ATTR}]),` +
    `html[data-substack-villages-sort="on"]:not([data-sv-reader]) [aria-label="Note"]:not([${SEEN_ATTR}]),` +
    `html[data-substack-villages-sort="on"]:not([data-sv-reader]) [aria-label="Post"]:not([${SEEN_ATTR}]){display:none!important}` +
    // Cards nested inside a card (body wrapper, quoted note) follow their parent, never hidden alone.
    `html[data-substack-villages] [aria-label="Note"] [aria-label="Note"]:not([${SEEN_ATTR}]),` +
    `html[data-substack-villages] [aria-label="Note"] [aria-label="Post"]:not([${SEEN_ATTR}]),` +
    `html[data-substack-villages] [aria-label="Post"] [aria-label="Note"]:not([${SEEN_ATTR}]),` +
    `html[data-substack-villages] [aria-label="Post"] [aria-label="Post"]:not([${SEEN_ATTR}]){display:revert!important}` +
    // Villages only: one calm status panel at the end of the feed instead of text that blinks on
    // and off every pass. It fades in, breathes while Substack is fetching, and fades out once a
    // batch is found. While searching the feed may shrink: Substack's end-of-list loader has to
    // come into view to fetch the next page. Only when Substack runs out is the feed propped open.
    // (Anna, 2026-09-29: "not strobing… some kind of softer way to animate loading".)
    `@keyframes sv-breathe{0%,100%{opacity:.45}50%{opacity:1}}` +
    `@keyframes sv-fade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}` +
    // Ended: hide Substack's own loader and grey placeholders so it stops fetching. Otherwise the
    // feed kept fetching under the stopper, the search restarted, and the screen flashed between
    // the stopper and empty placeholders (Anna, 2026-10-10, "back and forth").
    `.${ACTIVE_CLASS}[data-sv-loading="end"]>:not([aria-label="Note"]):not([aria-label="Post"]){display:none!important}` +
    // First batch: every card stays invisible while Substack loads and the extension filters and
    // sorts, so the page doesn't flicker; the panel sits at the top. When the batch is found the
    // cover lifts and the cards fade in together, with the page held at the top. (Anna, 2026-09-29:
    // "load down the page while keeping the view pinned at the top".)
    `.${ACTIVE_CLASS}[data-sv-cover="1"]>*{opacity:0!important;pointer-events:none!important}` +
    `.${ACTIVE_CLASS}>*{transition:opacity .5s ease}` +
    // Matching cards ease in as they're found rather than popping.
    `html[data-substack-villages="on"] [${SEEN_ATTR}="keep"]{animation:sv-fade .45s ease both}` +
    // Substack's own grey loading placeholders flash while pages load; hide them (kept in layout so
    // its end-of-list loader still fires). Best guess at their markup — not verified live.
    `html[data-substack-villages="on"] [aria-label="Notes feed"] [aria-busy="true"],` +
    `html[data-substack-villages="on"] [aria-label="Notes feed"] [class*="skeleton" i],` +
    `html[data-substack-villages="on"] [aria-label="Notes feed"] [class*="placeholder" i]{opacity:0!important}`;
  document.documentElement.append(style);
  // The curtain: while a batch is being found, the feed is clipped at the bottom of the screen so
  // Substack's end-of-list loader stays in view and keeps fetching, however many matches already
  // fill the screen. The clip height is set per pass; lifting it only extends the page downward.
  const clipStyle = document.createElement("style");
  document.documentElement.append(clipStyle);

  // The haystack loader, drawn to Anna's marked-up frames (_Agent Mail/reference-Stackyard-
  // animation.jpg, 2026-10-01). The original mound on a brown floor line, gaining straw lines as it
  // grows (a few cross the outline). The fork lies on the ground to the right with a tuft of hay on
  // its tines, swings counterclockwise up to upright and flings the tuft up and over onto the
  // stack, follows through toward it, then drops back down for the next tuft. A line of silly
  // haystack talk changes every couple of seconds; finding a match is good news ("I found it!!!").
  // It sits outside the feed (fixed to the screen, centered on the feed column), so the feed's
  // clip can never hide it.
  const LINES = ["Pitching hay…", "Fluffing the stack…", "Shooing the chickens…", "Sifting for needles…",
    "Finding the good stuff for you…", "Checking under every straw…", "Asking the barn cat…",
    "Stacking it nice and high…", "Brushing off the chaff…", "Counting straws (lost count)…"];
  const FOUND = ["Oh! Found a needle!", "I found it!!!", "There's one!", "A needle! Hooray!"];
  // A small haystack means a long search through the feed. After a little while, say so kindly
  // instead of only joking (Anna, 2026-10-10, testing with her small Carrierfile haystack).
  const PATIENCE_AFTER_MS = 6000;
  const PATIENCE = ["Small haystack, so this may take a minute…", "Still digging. Your haystack is choosy.",
    "Fewer straws means a longer search…", "Still looking. Good needles are worth it."];
  let searchStartedAt = 0, patienceIndex = 0;
  const HAY = "#E9B949", HAY_DARK = "#C98A26", HAY_LINE = "#8A5A14";
  const DOME = "M-38 0 C-38 -36 -21 -64 0 -64 C21 -64 38 -36 38 0 Z";
  // Straw lines in three sets: always, from middle size, from large size (Anna's frames show
  // 2, then about 4, then about 7). Some run past the outline.
  const STRAWS_1 = "M-20 -40 C-12 -44 -4 -44 4 -42 M-6 -20 C2 -24 12 -24 20 -21";
  const STRAWS_2 = "M-14 -54 C-8 -57 -2 -57 4 -55 M-46 -6 C-38 -12 -30 -14 -20 -13 M18 -49 C25 -52 31 -50 36 -45";
  const STRAWS_3 = "M-44 -26 C-36 -31 -26 -32 -16 -30 M8 -6 C16 -9 24 -9 31 -7 M9 -61 C15 -64 21 -62 26 -57";
  // A tuft of hay: loose straws crossing every which way (scene units, centered on 0,0).
  const TUFT = `<path d="M-7 -2 L6 3 M-5 4 L5 -5 M-2 -7 L2 7 M-8 2 L7 -1 M-4 -6 L6 5" stroke="${HAY}" stroke-width="1.8" stroke-linecap="round"/>` +
    `<path d="M-6 -5 L4 6 M-7 0 L7 1 M1 -7 L-2 6" stroke="${HAY_DARK}" stroke-width="1.3" stroke-linecap="round"/>` +
    `<path d="M-5 1 L3 -4 M-1 4 L6 -2" stroke="${HAY_LINE}" stroke-width=".9" stroke-linecap="round"/>`;
  const PIVOT_X = 112, FLOOR_Y = 92;   // the fork's handle end, on the floor
  const HANDLE = 27, TINE = 9;         // a short handle; three tines the same length (not a trident)
  const TIP = FLOOR_Y - HANDLE - TINE;
  const MS = 1600;   // one tuft
  const loaderStyle = document.createElement("style");
  // Built from separate HTML pieces that only move (transform) and fade (opacity), driven by
  // the Web Animations API on one shared clock. Browsers run those off the page's main thread,
  // so the animation stays smooth and in step while Stackyard and Substack are busy with the feed
  // (Anna, 2026-10-10: "it's not following its frames", the double hay, the shrinking stack).
  loaderStyle.textContent =
    // Step aside for Substack's own pop-ups (v0.6.46–47, Anna: the loader sat on top of the Note
    // composer, twice). The loader lives outside <body>, so test from <html>: any open dialog, the
    // scroll lock Substack puts on <body> under a pop-up, or its "hasModal-…" class. And sit low
    // (z-index 90): above the feed, under any overlay, if a pop-up shows none of those signs.
    `html[class*="hasModal"] .sv-loader,html:has([role="dialog"]) .sv-loader,html:has([role="alertdialog"]) .sv-loader,` +
    `html:has(body[data-scroll-locked]) .sv-loader,html:has(body[style*="pointer-events: none"]) .sv-loader{display:none!important}` +
    `.sv-loader{position:fixed;z-index:90;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:2px;` +
    `width:320px;box-sizing:border-box;text-align:center;padding:10px 20px 12px;border-radius:18px;border:1px solid rgba(127,127,127,.22);` +
    `box-shadow:0 4px 18px rgba(0,0,0,.08);font:600 13px -apple-system,BlinkMacSystemFont,"SF Pro Text",system-ui,sans-serif;` +
    `opacity:0;pointer-events:none;transition:opacity .5s ease}` +
    `.sv-loader.is-on{opacity:1}` +
    `.sv-scene{position:relative;width:160px;height:100px}` +
    `.sv-scene>div,.sv-fork>div{position:absolute;will-change:transform}` +
    `.sv-scene svg{display:block;overflow:visible}` +
    // The stack grows smoothly and never overshoots (an overshoot settling back read as losing hay).
    `.sv-stack{left:24px;top:${FLOOR_Y - 66}px;width:80px;height:68px;transform-origin:40px 66px;transition:transform .6s ease-out}` +
    `.sv-bump{inset:0;transform-origin:40px 66px}` +
    `.sv-straws-2,.sv-straws-3{opacity:0;transition:opacity .6s ease}` +
    `.sv-loader[data-size="2"] .sv-straws-2,.sv-loader[data-size="3"] .sv-straws-2,.sv-loader[data-size="3"] .sv-straws-3{opacity:1}` +
    `.sv-fork{left:${PIVOT_X - 16}px;top:${TIP - 16}px;width:32px;height:${FLOOR_Y - TIP + 16}px;transform-origin:16px ${FLOOR_Y - TIP + 16}px}` +
    `.sv-tuft{width:16px;height:16px}` +
    `.sv-ontines{left:8px;top:7px}` +
    `.sv-fly{left:0;top:0;opacity:0}` +
    `.sv-loader .sv-msg{min-height:18px}` +
    `.sv-loader .sv-count{font-weight:500;font-size:11px;opacity:.6}`;
  document.documentElement.append(loaderStyle);
  const loaderEl = document.createElement("div");
  loaderEl.className = "sv-loader";
  loaderEl.setAttribute("role", "status");
  const ns = 'vector-effect="non-scaling-stroke"';
  const tuftSvg = `<svg width="16" height="16" viewBox="-8 -8 16 16" aria-hidden="true">${TUFT}</svg>`;
  loaderEl.innerHTML =
    `<div class="sv-scene" aria-hidden="true">` +
    `<svg width="160" height="100" viewBox="0 0 160 100" style="position:absolute;left:0;top:0"><path d="M14 ${FLOOR_Y} H150" stroke="${HAY_LINE}" stroke-width="3" stroke-linecap="round"/></svg>` +
    `<div class="sv-stack" style="transform:scale(.3)"><div class="sv-bump"><svg width="80" height="68" viewBox="-40 -66 80 68">` +
    `<path d="${DOME}" fill="${HAY}" stroke="${HAY_LINE}" stroke-width="2.2" stroke-linejoin="round" ${ns}/>` +
    `<g fill="none" stroke="${HAY_LINE}" stroke-width="1.8" stroke-linecap="round">` +
    `<path d="${STRAWS_1}" ${ns}/><path class="sv-straws-2" d="${STRAWS_2}" ${ns}/><path class="sv-straws-3" d="${STRAWS_3}" ${ns}/></g>` +
    `</svg></div></div>` +
    // the fork, drawn upright; its box's bottom center is the handle end on the floor
    `<div class="sv-fork"><svg width="32" height="${FLOOR_Y - TIP + 16}" viewBox="${PIVOT_X - 16} ${TIP - 16} 32 ${FLOOR_Y - TIP + 16}" stroke-linecap="round" fill="none">` +
    `<path d="M${PIVOT_X} ${FLOOR_Y} V${FLOOR_Y - HANDLE}" stroke="currentColor" stroke-width="3.2"/>` +
    `<path d="M${PIVOT_X - 6} ${FLOOR_Y - HANDLE} H${PIVOT_X + 6}" stroke="currentColor" stroke-width="2.8"/>` +
    `<path d="M${PIVOT_X - 6} ${FLOOR_Y - HANDLE} V${TIP} M${PIVOT_X} ${FLOOR_Y - HANDLE} V${TIP} M${PIVOT_X + 6} ${FLOOR_Y - HANDLE} V${TIP}" stroke="currentColor" stroke-width="2.4"/>` +
    `</svg><div class="sv-tuft sv-ontines">${tuftSvg}</div></div>` +
    `<div class="sv-tuft sv-fly">${tuftSvg}</div>` +
    `</div><div class="sv-msg"></div><div class="sv-count"></div>`;
  document.documentElement.append(loaderEl);

  // One clock for every moving part: same duration, same start, paused and resumed together.
  // rest on the ground (pointing right) → scoop up → upright, the tuft lets go → follow through
  // toward the stack → back down to the ground for the next tuft
  const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const forkEl = loaderEl.querySelector(".sv-fork"), flyEl = loaderEl.querySelector(".sv-fly");
  const loop = { duration: MS, iterations: Infinity };
  const anims = still ? [] : [
    forkEl.animate([
      { offset: 0, transform: "rotate(86deg)" }, { offset: .1, transform: "rotate(86deg)", easing: "ease-in-out" },
      { offset: .36, transform: "rotate(48deg)", easing: "ease-in-out" }, { offset: .5, transform: "rotate(0deg)", easing: "ease-in-out" },
      { offset: .62, transform: "rotate(-24deg)", easing: "ease-in-out" }, { offset: .74, transform: "rotate(-14deg)", easing: "ease-in-out" },
      { offset: 1, transform: "rotate(86deg)" }], loop),
    // the tuft on the tines: there until the fork lets go, back once it's down for the next scoop
    loaderEl.querySelector(".sv-ontines").animate([
      { offset: 0, opacity: 1 }, { offset: .498, opacity: 1 }, { offset: .499, opacity: 0 },
      { offset: .95, opacity: 0 }, { offset: .951, opacity: 1 }, { offset: 1, opacity: 1 }], loop),
    loaderEl.querySelector(".sv-bump").animate([
      { offset: 0, transform: "scale(1)" }, { offset: .75, transform: "scale(1)" }, { offset: .81, transform: "scale(1.05,.96)" },
      { offset: .9, transform: "scale(1)" }, { offset: 1, transform: "scale(1)" }], { ...loop, easing: "ease-out" }),
    flyEl.animate(flightFrames(FLOOR_Y - 64 * 0.3), loop)];
  if (still) forkEl.style.transform = "rotate(30deg)";
  // The flung tuft: from the tines (fork upright) in an arc to the top of the stack, spinning.
  function flightFrames(top) {
    const x0 = PIVOT_X, y0 = TIP - 1, cx = 86, cy = Math.min(top, TIP) - 26, x1 = 64, y1 = top - 3;
    const at = (t) => [(1 - t) ** 2 * x0 + 2 * (1 - t) * t * cx + t * t * x1, (1 - t) ** 2 * y0 + 2 * (1 - t) * t * cy + t * t * y1];
    const pose = (t, opacity) => { const [x, y] = at(t); return `translate(${(x - 8).toFixed(1)}px,${(y - 8).toFixed(1)}px) rotate(${(-220 * t).toFixed(0)}deg)`; };
    const frames = [{ offset: 0, opacity: 0, transform: pose(0) }, { offset: .498, opacity: 0, transform: pose(0) }];
    for (const u of [0, .2, .4, .6, .8, 1]) {
      const t = 1 - (1 - u) ** 1.6;   // quick off the fork, slowing into the landing
      frames.push({ offset: .499 + u * (.76 - .499), opacity: 1, transform: pose(t) });
    }
    frames.push({ offset: .78, opacity: 0, transform: pose(1) }, { offset: 1, opacity: 0, transform: pose(1) });
    return frames;
  }
  let playing = !still;
  function setPlaying(on) {
    if (still || on === playing) return;
    playing = on;
    const t = anims[0].currentTime;   // resume every part from the same moment
    for (const a of anims) { if (on) { a.currentTime = t; a.play(); } else a.pause(); }
  }
  setPlaying(false);   // hidden = still: no animation work while the loader isn't shown

  // The stopper: when a search runs out before finding its batch, a card at the end of the feed
  // explains why and what helps (Anna, 2026-10-10: "make it fun… finding needles in one haystack
  // might seem like a good idea but ACTUALLY makes it harder"). Sits after the feed, outside
  // Substack's own list, and goes away as soon as searching starts again.
  const stopperStyle = document.createElement("style");
  stopperStyle.textContent =
    `.sv-stopper{box-sizing:border-box;margin:24px auto 40px;max-width:520px;padding:20px 24px 18px;border:1px solid rgba(127,127,127,.22);` +
    `border-radius:18px;text-align:center;font:15px/1.5 -apple-system,BlinkMacSystemFont,"SF Pro Text",system-ui,sans-serif;animation:sv-fade .45s ease both}` +
    `.sv-stopper svg{display:block;margin:0 auto 6px;width:120px;height:64px}` +
    `.sv-stopper h3{margin:0 0 6px;font-size:17px;font-weight:700}` +
    `.sv-stopper p{margin:0 0 8px}` +
    `.sv-stopper .sv-stopper-how{font-size:13px;opacity:.75}` +
    `.sv-stopper .sv-stopper-count{font-size:12px;opacity:.55;margin:0 0 10px}` +
    `.sv-stopper .sv-stopper-more{font:600 13px inherit;font-family:inherit;padding:6px 16px;border-radius:999px;border:1px solid currentColor;background:none;color:inherit;cursor:pointer;opacity:.85}` +
    `.sv-stopper .sv-stopper-more:hover{opacity:1}`;
  document.documentElement.append(stopperStyle);
  let stopperEl = null;
  function showStopper(feedEl, shown, checked) {
    if (!stopperEl) {
      stopperEl = document.createElement("div");
      stopperEl.className = "sv-stopper";
      stopperEl.setAttribute("role", "note");
      // A lone, small haystack with the fork lying beside it.
      stopperEl.innerHTML =
        `<svg viewBox="0 0 120 64" aria-hidden="true"><path d="M8 58 H112" stroke="${HAY_LINE}" stroke-width="3" stroke-linecap="round"/>` +
        `<g transform="translate(46 58) scale(.55)"><path d="${DOME}" fill="${HAY}" stroke="${HAY_LINE}" stroke-width="4" stroke-linejoin="round"/>` +
        `<path d="${STRAWS_1}" fill="none" stroke="${HAY_LINE}" stroke-width="3" stroke-linecap="round"/></g>` +
        `<g stroke="currentColor" stroke-linecap="round" fill="none"><path d="M78 57 H100" stroke-width="3"/><path d="M100 51 V63 M100 51 H108 M100 57 H108 M100 63 H108" stroke-width="2.4"/></g></svg>` +
        `<h3>One tiny haystack, very few needles</h3>` +
        `<p>Searching just one haystack sounds tidy. Plot twist: it's the slow way. The smaller the stack, ` +
        `the longer we dig for every needle. Pile on another haystack and the needles show up faster.</p>` +
        `<p class="sv-stopper-how">Add one from the haystack button in your browser toolbar.</p>` +
        `<p class="sv-stopper-count"></p>` +
        `<button type="button" class="sv-stopper-more">Keep digging <span aria-hidden="true">↓</span></button>`;
      stopperEl.querySelector(".sv-stopper-more").addEventListener("click", () => {
        const [found] = (document.documentElement.dataset.substackVillagesCount || "0/0").split("/").map(Number);
        ended = false; target = found + BATCH; lastGrowthAt = Date.now();
        autoloadCap = Math.max(autoloadCap, candidates().length + 300);   // room to dig further
        hideStopper(); schedule();
      });
    }
    const multiple = (settings?.sources || []).filter((src) => src.enabled).length > 1;
    stopperEl.querySelector("h3").textContent = multiple ? "Your haystacks are running thin" : "One tiny haystack, very few needles";
    stopperEl.querySelector("p").textContent = multiple
      ? "Small haystacks hide very few needles, so we dig a long time for each one. Pile on another haystack and the needles show up faster."
      : "Searching just one haystack sounds tidy. Plot twist: it's the slow way. The smaller the stack, the longer we dig for every needle. Pile on another haystack and the needles show up faster.";
    stopperEl.querySelector(".sv-stopper-count").textContent = `${shown} found in ${checked} checked`;
    stopperEl.style.color = getComputedStyle(feedEl).color;
    if (stopperEl.previousElementSibling !== feedEl) feedEl.after(stopperEl);
  }
  function hideStopper() { stopperEl?.remove(); }
  globalThis.__svDev = { showStopper, hideStopper };   // for dev/loader-test.html (content scripts run in their own world)
  let lineIndex = Math.floor(Math.random() * LINES.length), lineTimer = null, lastShown = -1, foundUntil = 0, lastScale = 0, maxScale = 0.3;
  function sayLine(text) {
    // Words change at once, then fade in. The old fade-out-then-swap waited on a timer that a busy
    // page delayed, which left the line blank (Anna, 2026-10-10).
    const msg = loaderEl.querySelector(".sv-msg");
    if (msg.textContent === text) return;
    msg.textContent = text;
    if (!still) msg.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 220, easing: "ease-out" });
  }
  // The stack's size, how many straw lines it shows, and where the flung tuft lands (its top).
  // During a search it only grows: a note Substack swaps out of the page no longer shrinks it.
  function setStackScale(scale) {
    scale = Math.max(scale, maxScale);
    maxScale = scale;
    if (scale === lastScale) return;
    lastScale = scale;
    loaderEl.querySelector(".sv-stack").style.transform = `scale(${scale})`;
    loaderEl.dataset.size = scale >= 0.8 ? "3" : scale >= 0.5 ? "2" : "1";
    if (!still) anims[3].effect.setKeyframes(flightFrames(FLOOR_Y - 64 * scale));
  }
  setStackScale(0.3);
  globalThis.__svDev.setStackScale = setStackScale;
  // state: "off" | "search" | "end"; place: "top" (behind the first-batch cover) | "bottom"
  function updateLoader(state, place, shown, goal, checked, feedEl) {
    // The haystack belongs to the Home feed only. Anna saw it on her profile page (2026-10-10):
    // whatever path left it on, it never shows anywhere else.
    if (!U.isHomeFeedUrl(location.href) || !feedEl) state = "off";
    const on = state !== "off";
    loaderEl.classList.toggle("is-on", on);
    setPlaying(on);
    if (!on) {
      maxScale = 0.3;   // the next search starts from a small stack again
      delete loaderEl.dataset.colored;
      if (lineTimer) { clearInterval(lineTimer); lineTimer = null; }
      lastShown = -1;
      searchStartedAt = 0;
      return;
    }
    const rect = feedEl.getBoundingClientRect();
    loaderEl.style.left = `${Math.round(rect.left + rect.width / 2)}px`;
    loaderEl.style.top = place === "top" ? `${Math.max(90, Math.round(Math.min(rect.top, innerHeight) + 40))}px` : "auto";
    loaderEl.style.bottom = place === "top" ? "auto" : "18px";
    if (!loaderEl.dataset.colored) {
      const page = getComputedStyle(document.body);
      loaderEl.style.color = getComputedStyle(feedEl).color;
      loaderEl.style.background = page.backgroundColor && page.backgroundColor !== "rgba(0, 0, 0, 0)" ? page.backgroundColor : "#fff";
      loaderEl.dataset.colored = "1";
    }
    const progress = state === "end" ? 1 : Math.min(1, shown / Math.max(1, goal));
    setStackScale(Number((0.3 + 0.7 * progress).toFixed(3)));
    const countText = state === "end" ? `${shown} found in ${checked} checked` : `${Math.min(shown, goal)} of ${goal}`;
    const countEl = loaderEl.querySelector(".sv-count");
    if (countEl.textContent !== countText) countEl.textContent = countText;
    if (state === "end") { if (lineTimer) { clearInterval(lineTimer); lineTimer = null; } sayLine("That's everything Substack sent for now."); return; }
    if (lastShown >= 0 && shown > lastShown) {
      sayLine(FOUND[Math.floor(Math.random() * FOUND.length)]);
      foundUntil = Date.now() + 1600;
    } else if (lastShown < 0) sayLine(LINES[lineIndex]);
    lastShown = shown;
    if (!searchStartedAt) searchStartedAt = Date.now();
    if (!lineTimer) lineTimer = setInterval(() => {
      if (Date.now() < foundUntil) return;
      // Past the first few seconds, every other line is a patience line.
      if (Date.now() - searchStartedAt > PATIENCE_AFTER_MS && lineIndex % 2 === 0) {
        lineIndex++;
        sayLine(PATIENCE[patienceIndex++ % PATIENCE.length]);
        return;
      }
      lineIndex = (lineIndex + 1) % LINES.length;
      sayLine(LINES[lineIndex]);
    }, 2400);
  }

  function candidates() {
    // Every top-level Note/Post card on the page, not only those inside the "Notes feed" block:
    // Substack sometimes renders a card or two above the feed in a separate container, and those
    // were slipping through unfiltered (Anna, 2026-09-23 17:29).
    const main = document.querySelector("main") || document.body;
    const cards = [...main.querySelectorAll('[aria-label="Note"],[aria-label="Post"]')]
      .filter((card) => !card.parentElement?.closest('[aria-label="Note"],[aria-label="Post"]'));
    if (cards.length) return cards;
    return [...main.querySelectorAll('article,[data-testid="feed-item"],[data-testid="post-feed-item"]')]
      .filter((card) => !card.parentElement?.closest('article,[data-testid="feed-item"],[data-testid="post-feed-item"]'));
  }

  // A card's sort time is read ONCE and then frozen. Substack keeps mutating cards after they
  // render (Anna likes one, a count ticks, a "You liked" line appears, React swaps the node), and
  // re-reading the time on every pass is what made the feed jump after a like (Anna, 2026-09-29).
  // Keyed by the note/post permalink so a re-rendered node keeps its place; the element map
  // covers cards without a permalink.
  const timesByKey = new Map();
  const timesByCard = new WeakMap();
  function frozenTime(card) {
    if (timesByCard.has(card)) return timesByCard.get(card);
    const key = U.cardKey(card);
    let time = key && timesByKey.has(key) ? timesByKey.get(key) : U.cardTimestamp(card);
    // Don't freeze an empty read: Substack fills cards in after first render.
    if (time === null) return null;
    if (key) timesByKey.set(key, time);
    timesByCard.set(card, time);
    return time;
  }

  const placedByKey = new Map();
  let placedCount = 0;
  function forgetPlaces() { placedByKey.clear(); placedCount = 0; }
  const keys = new WeakMap();   // permalink per card element, read once it exists
  function keyOf(card) {
    if (keys.has(card)) return keys.get(card);
    const key = U.cardKey(card);
    if (key) keys.set(card, key);
    return key;
  }
  function sortCards(cards, active) {
    if (!active) {
      for (const [element, original] of originalOrders) element.style.order = original;
      originalOrders.clear();
      lastSortKey = "";
      document.querySelectorAll(`.${SORTED_CLASS}`).forEach((el) => el.classList.remove(SORTED_CLASS));
      return;
    }
    // Sort within the main feed container only (the one holding most cards); stray cards in
    // other containers are filtered but left where they are.
    const counts = new Map();
    for (const card of cards) counts.set(card.parentElement, (counts.get(card.parentElement) || 0) + 1);
    const parent = [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
    cards = cards.filter((card) => card.parentElement === parent);
    if (!parent || !cards.length || getComputedStyle(parent).display !== "flex") return;
    parent.classList.add(SORTED_CLASS);
    const children = [...parent.children];
    const cardSet = new Set(cards);
    const cardSlots = children.map((child, index) => cardSet.has(child) ? index : -1).filter((index) => index >= 0);
    // Notes already shown keep their place; newly found ones go below them, newest first among
    // themselves. Re-sorting everything let a newer match jump above what Anna was reading
    // (2026-10-10: "avoid posts moving around… just load more in a small batch"). Places are
    // keyed by permalink so a card Substack re-renders (after a like) keeps its spot.
    const rank = (card) => { const key = keyOf(card); return key && placedByKey.has(key) ? placedByKey.get(key) : Infinity; };
    const sorted = cards.map((card, index) => ({ card, index, time: frozenTime(card), rank: rank(card) }))
      .sort((a, b) => (a.rank - b.rank) || (b.time ?? -Infinity) - (a.time ?? -Infinity) || a.index - b.index);
    if (!firstBatch) for (const { card } of sorted) {
      if (card.classList.contains(HIDDEN_CLASS) || card.getAttribute(SEEN_ATTR) !== "keep") continue;
      const key = keyOf(card);
      if (key && !placedByKey.has(key)) placedByKey.set(key, placedCount++);
    }
    // Skip the whole reorder when nothing about the sequence changed — every reorder is a
    // chance for the page to jump, and Substack mutates the feed constantly (video players,
    // reaction counts, auto-loading more items).
    const sortKey = sorted.map(({ index }) => index).join(",") + "|" + children.length;
    if (sortKey === lastSortKey) return;
    lastSortKey = sortKey;
    // Anchor the viewport on the VISUALLY topmost kept card (smallest bottom edge still on
    // screen), so a reorder doesn't move what Anna is reading. DOM order is not visual order
    // once cards carry flex `order`, so "first in the list" would anchor on the wrong card and
    // scroll to correct a shift she never saw — the jump caught in the 17:29 recording.
    let anchor = null, anchorTop = null, anchorBottom = Infinity;
    for (const card of cards) {
      if (card.classList.contains(HIDDEN_CLASS)) continue;
      const rect = card.getBoundingClientRect();
      if (rect.bottom > 0 && rect.bottom < anchorBottom) { anchor = card; anchorTop = rect.top; anchorBottom = rect.bottom; }
    }
    const positions = new Map(sorted.map(({ card }, index) => [card, cardSlots[index]]));
    children.forEach((child, index) => {
      if (!cardSet.has(child)) return;   // non-cards are pinned to the bottom by CSS
      if (!originalOrders.has(child)) originalOrders.set(child, child.style.order);
      const order = String(positions.get(child) ?? index);
      if (child.style.order !== order) child.style.order = order;
    });
    // At the top of the page, stay at the top: newer cards land above and are simply seen. Only
    // once Anna has scrolled into the feed does the view hold on the card she's reading.
    const covered = document.querySelector(`[data-sv-cover="1"]`);
    if (anchor && anchorTop !== null && window.scrollY > 10 && !covered) {
      const delta = anchor.getBoundingClientRect().top - anchorTop;
      if (Math.abs(delta) > 1) window.scrollBy(0, delta);
    }
  }

  function hideNonContent(active) {
    const feed = document.querySelector('[aria-label="Notes feed"]');
    if (!feed) return;
    for (const section of feed.children) {
      const heading = section.querySelector('h1,h2,h3,h4');
      if (heading?.textContent?.trim() === "People to follow" || section.getAttribute("aria-label") === "Chat") {
        section.classList.toggle(HIDDEN_CLASS, Boolean(active));
      }
    }
  }

  function updateClip() {
    const feedEl = document.querySelector('[aria-label="Notes feed"]');
    const on = feedEl?.getAttribute("data-sv-loading") === "1";
    const clip = on ? Math.max(240, Math.round(innerHeight - feedEl.getBoundingClientRect().top - 4)) : 0;
    const css = clip ? `.${ACTIVE_CLASS}[data-sv-loading="1"]{max-height:${clip}px!important;overflow:hidden!important;position:relative!important}` : "";
    if (clipStyle.textContent !== css) clipStyle.textContent = css;
    // Substack fetches on scroll / intersection; while searching, nudge it every second rather
    // than only when a page lands, so one missed nudge can't stall the search.
    // A full filter pass from the timer only when the stall guard may be due; every other pass is
    // driven by actual page changes. (A pass every second kept the browser busy and made the
    // loader stutter, Anna 2026-10-01.)
    if (on && !nudgeTimer) nudgeTimer = setInterval(() => {
      window.dispatchEvent(new Event("scroll"));
      if (Date.now() - lastGrowthAt > STALL_MS) schedule();
    }, 1000);
    if (!on && nudgeTimer) { clearInterval(nudgeTimer); nudgeTimer = null; }
  }

  function isReaderOverFeed() {
    // A post or note opened from a feed (/home/post/p-123): Substack keeps the feed mounted
    // underneath. Leave it exactly as it is. Un-hiding and un-sorting it here made the page
    // longer, so closing the post landed Anna further down the feed (2026-10-10).
    return /^\/(home|following|notes|feed)\//.test(location.pathname) && !U.isHomeFeedUrl(location.href);
  }

  // Where the reader was in the feed: the topmost visible card's permalink and how far it sat from
  // the top of the screen. Recorded on every real scroll of the feed, restored after a post opened
  // over the feed is closed. Freezing the feed alone didn't hold the place (Anna, 2026-10-10:
  // closed the AI Meets Girlboss post and landed a few cards further down).
  let readingAt = null, restoreUntil = 0;
  let recordQueued = false;
  function recordReadingPlace() {
    // Once per frame. The visually topmost card, not the first in the DOM: sorted cards carry a
    // flex order, so DOM order isn't screen order.
    if (recordQueued) return;
    recordQueued = true;
    requestAnimationFrame(() => {
      recordQueued = false;
      if (document.documentElement.dataset.svReader) return;
      let best = null;
      for (const card of candidates()) {
        if (card.classList.contains(HIDDEN_CLASS)) continue;
        const rect = card.getBoundingClientRect();
        if (rect.height === 0 || rect.bottom <= 0 || rect.top >= innerHeight) continue;
        if (!best || rect.bottom < best.bottom) { const key = U.cardKey(card); if (key) best = { key, top: rect.top, bottom: rect.bottom }; }
      }
      if (best) readingAt = { key: best.key, top: best.top };
    });
  }
  function restoreReadingPlace() {
    if (!readingAt || Date.now() > restoreUntil) return;
    const card = candidates().find((c) => U.cardKey(c) === readingAt.key && !c.classList.contains(HIDDEN_CLASS));
    if (!card) return;
    const delta = card.getBoundingClientRect().top - readingAt.top;
    if (Math.abs(delta) > 1) window.scrollBy(0, delta);
  }

  function applyFilter() {
    scheduled = null;
    if (isReaderOverFeed()) {
      document.documentElement.dataset.svReader = "1";
      updateLoader("off");
      return;
    }
    if (document.documentElement.dataset.svReader) {
      // Back from a post: Substack restores its own scroll and re-renders over the next moment, so
      // keep putting the card back for a little while, then let go.
      delete document.documentElement.dataset.svReader;
      restoreUntil = Date.now() + 1500;
      for (const ms of [0, 150, 400, 800, 1300]) setTimeout(restoreReadingPlace, ms);
    }
    const cards = candidates();
    const recs = U.villageRecommendations(settings);
    const homeFeed = U.isHomeFeedUrl(location.href);
    // No lists loaded yet means nothing to match against: leave Substack's feed alone rather than
    // hide every card (Dinah, 2026-10-10: blank feed, "0 found in 878 checked").
    const active = settings?.enabled && homeFeed && Boolean(settings.refreshedAt) && recs.length > 0;
    let shown = 0;
    // Newest first is its own switch: it sorts the Home feed whether or not the village filter
    // is on (Anna, 2026-09-29: filter OFF + Newest first left a 43m note above a 1m note).
    const sorting = Boolean(homeFeed && settings?.newestFirst);
    let pending = false;
    for (const card of cards) {
      let keep = true;
      // Fast path: a card already judged, fully rendered and placed needs nothing this pass but
      // counting. Touching every card on every pass is what slowed the haystack down once 0.6.11
      // let passes run during loading (Anna, 2026-10-10: "slow and weird", "like it's stuck").
      if (active && card.hasAttribute(SEEN_ATTR) && card.hasAttribute(SETTLED_ATTR)) {
        const cached = verdicts.get(card);
        if (cached && cached.v === verdictVersion) { if (cached.keep) shown++; continue; }
      }
      if (active) {
        const cached = verdicts.get(card);
        if (cached && cached.v === verdictVersion) keep = cached.keep;
        else {
          keep = U.cardMatches(card, recs, settings.mode, settings.includeReposts);
          // Only a fully rendered card (it has its permalink) gets a cached verdict; Substack
          // fills cards in after first render, and an early read can miss the byline.
          if (U.cardKey(card)) { verdicts.set(card, { v: verdictVersion, keep }); card.setAttribute(SETTLED_ATTR, ""); }
        }
      }
      card.classList.toggle(HIDDEN_CLASS, !keep);
      // Newest first: a kept card whose timestamp hasn't rendered yet stays invisible for a
      // moment instead of showing at the bottom and then leaping up once its date appears.
      if (sorting && keep && !card.hasAttribute(SEEN_ATTR) && frozenTime(card) === null) {
        if (!firstSeen.has(card)) firstSeen.set(card, Date.now());
        if (Date.now() - firstSeen.get(card) < DATE_WAIT_MS) { pending = true; continue; }
      }
      card.setAttribute(SEEN_ATTR, keep ? "keep" : "hide");
      // Nested Note/Post elements (body wrappers, quoted notes) are exempted by CSS now, rather
      // than marked one by one on every pass.
      if (keep) shown++;
    }
    // Few matches: let the feed collapse so Substack's own end-of-list sentinel comes into view and
    // it fetches the next page (its loader is scroll/intersection driven). Nudge it with a scroll
    // event. Once `target` cards match, or autoloadCap cards are loaded, prop the feed open
    // again so it stops.
    const feedEl = document.querySelector('[aria-label="Notes feed"]');
    if (cards.length > lastCardCount) lastGrowthAt = Date.now();
    lastCardCount = cards.length;
    // Substack stopped sending (end of its feed, or it lost interest in our nudges): end the
    // search with a message instead of leaving a blank, clipped feed (Dinah: "the screen goes blank").
    const stalled = active && shown < target && Date.now() - lastGrowthAt > STALL_MS;
    const atCap = cards.length >= autoloadCap || stalled;
    if (active && atCap && shown < target) ended = true;
    if (shown >= target) ended = false;
    const wantMore = active && shown < target && !atCap && !ended;
    // Loading switches ON at once but OFF only after it has stayed done for SETTLE_MS, so a pass
    // that briefly reaches the target can't blink the panel.
    if (wantMore) { clearTimeout(loadingOffTimer); loadingOffTimer = null; loading = true; }
    else if (loading && !loadingOffTimer) loadingOffTimer = setTimeout(() => { loading = false; loadingOffTimer = null; schedule(); }, SETTLE_MS);
    if (feedEl) {
      feedEl.classList.toggle(ACTIVE_CLASS, Boolean(active));
      const status = active && atCap && shown < target ? `End of what Substack loaded · ${shown} found in ${cards.length} checked`
        : `Searching the haystack · ${Math.min(shown, target)} of ${target}`;   // kept for debugging; the loader shows it
      if (feedEl.getAttribute("data-sv-status") !== status) feedEl.setAttribute("data-sv-status", status);
      const state = !active ? "0" : loading ? "1" : (atCap || ended) && shown < target ? "end" : "0";
      if (feedEl.getAttribute("data-sv-loading") !== state) feedEl.setAttribute("data-sv-loading", state);
      const cover = active && firstBatch && state === "1" ? "1" : "0";
      // The first batch is over as soon as a search finishes, covered or not. It used to end only
      // if the cover had actually gone up, so a fast first batch left the flag set and the NEXT
      // batch (on scroll) covered the whole feed: blank screen with empty divider lines
      // (Anna, 2026-10-10, "doesn't smoothly load more").
      if (active && firstBatch && state !== "1") {
        const wasCovered = feedEl.getAttribute("data-sv-cover") === "1";
        firstBatch = false;
        if (wasCovered && window.scrollY > 0 && window.scrollY < innerHeight * 2) window.scrollTo(0, 0);
      }
      if (feedEl.getAttribute("data-sv-cover") !== cover) feedEl.setAttribute("data-sv-cover", cover);
      updateClip();
      // The "end" note shows briefly, then gets out of the way.
      if (state === "end" && endShownUntil === 0) { endShownUntil = Date.now() + 4000; setTimeout(schedule, 4100); }
      if (state !== "end") endShownUntil = 0;
      // At the end, go straight to the stopper card: no big end card over the notes.
      const loaderState = state === "1" ? "search" : "off";
      if (state === "end") showStopper(feedEl, shown, cards.length); else hideStopper();
      updateLoader(loaderState, cover === "1" ? "top" : "bottom", shown, target, cards.length, feedEl);
    } else { updateLoader("off"); hideStopper(); }
    if (wantMore && cards.length !== lastNudgedCount) {
      lastNudgedCount = cards.length;
      setTimeout(() => window.dispatchEvent(new Event("scroll")), 400);
    }
    hideNonContent(active);
    sortCards(cards, sorting);
    if (pending) setTimeout(schedule, 250);
    document.documentElement.dataset.substackVillages = active ? "on" : "off";
    document.documentElement.dataset.substackVillagesSort = sorting ? "on" : "off";
    document.documentElement.dataset.substackVillagesWhy = !settings?.enabled ? "switch-off" : !homeFeed ? `not-home:${location.pathname}` : !settings.refreshedAt ? "not-refreshed" : !recs.length ? "no-recommendations" : `${settings.mode}`;
    document.documentElement.dataset.substackVillagesCount = `${shown}/${cards.length}`;
  }

  // Debounce, with a ceiling. Substack fires mutations continuously while a feed loads; a plain
  // debounce kept resetting, so no pass ran until the churn stopped. The count sat at "0 of 10"
  // and then 30+ matches appeared at once (Anna, 2026-10-10, small Carrierfile haystack).
  // Now a pass always runs within MAX_WAIT_MS of the first change, however busy the page is.
  const MAX_WAIT_MS = 300;
  let scheduledAt = 0;
  function schedule() {
    if (scheduled) {
      if (Date.now() - scheduledAt >= MAX_WAIT_MS) return;   // the waiting pass runs as planned
      clearTimeout(scheduled);
    } else scheduledAt = Date.now();
    scheduled = setTimeout(() => requestAnimationFrame(applyFilter), 60);
  }

  // What the filter actually matches on. Storage writes that leave this unchanged (a haystack's
  // colors saved, the same list re-read) must not restart the feed: the Stackyard page and the
  // popup write sources/recommendations whenever they open, and each write used to bring the
  // haystack loader back over a feed Anna was already reading (2026-10-10 screenshots).
  let lastFilterSignature = null;
  function filterSignature() {
    const hosts = U.villageRecommendations(settings).flatMap((entry) => entry.hosts || [entry.host]).sort();
    return JSON.stringify([settings.enabled, settings.newestFirst, settings.mode, settings.includeReposts,
      Boolean(settings.refreshedAt), hosts]);
  }

  async function loadSettings() {
    settings = { ...U.DEFAULTS, ...(await chrome.storage.local.get(null)) };
    // Start over (cover + first batch) only when what the filter matches has changed.
    const signature = filterSignature();
    if (signature !== lastFilterSignature) {
      lastFilterSignature = signature;
      target = FIRST_BATCH; firstBatch = true; ended = false; lastGrowthAt = Date.now(); endShownUntil = 0; verdictVersion++; forgetPlaces();
      document.querySelectorAll(`[${SETTLED_ATTR}]`).forEach((el) => el.removeAttribute(SETTLED_ATTR));
    }
    schedule();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local") loadSettings();
  });
  new MutationObserver((records) => {
    if (location.href !== currentUrl) {
      currentUrl = location.href;
      // Leaving the Home feed: take the loader down now, not on the next debounced pass.
      if (!U.isHomeFeedUrl(location.href)) updateLoader("off");
      // Start over only on arriving at a DIFFERENT feed (For you → Following). Closing a post
      // opened from Home returns to the same feed, already loaded: no cover, no new search.
      else if (location.pathname.replace(/\/$/, "") !== lastFeedPath) {
        lastFeedPath = location.pathname.replace(/\/$/, "");
        lastSortKey = ""; target = FIRST_BATCH; firstBatch = true; ended = false; lastGrowthAt = Date.now(); endShownUntil = 0; forgetPlaces();
      }
    }
    // Ignore churn inside video players and other embeds, and inside cards that are already judged
    // and fully rendered (a like, a comment box, a ticking count): none of it changes the feed.
    if (records.every((record) => record.target.closest?.(`video,iframe,[data-testid*='video'],[class*='video'],[class*='player'],[${SETTLED_ATTR}],.sv-loader`))) return;
    schedule();
  }).observe(document.documentElement, { childList: true, subtree: true });
  // Next batch: when a batch is done and Anna scrolls within about a screen of the end, ask for
  // another BATCH. The panel fades back in while it's found.
  // Only a real scroll by the reader counts. Before 10/1 the extension's own nudge events (and the
  // clipped, short page) counted too, so the target crept 20 → 40 → … → 120 behind the cover: the
  // minute-long first load in Dinah's screenshots ("76 of 80").
  window.addEventListener("scroll", (event) => {
    if (document.documentElement.dataset.svReader) return;
    if (event.isTrusted && U.isHomeFeedUrl(location.href) && Date.now() > restoreUntil) recordReadingPlace();
    if (document.documentElement.dataset.substackVillages !== "on") return;
    if (loading) { updateClip(); return; }
    if (!event.isTrusted) return;
    const feedEl = document.querySelector('[aria-label="Notes feed"]');
    if (!feedEl || feedEl.getAttribute("data-sv-loading") === "1" || feedEl.getAttribute("data-sv-cover") === "1") return;
    if (feedEl.getBoundingClientRect().bottom > innerHeight * 2.2) return;
    const [shown] = (document.documentElement.dataset.substackVillagesCount || "0/0").split("/").map(Number);
    if (shown >= target) { target += BATCH; lastGrowthAt = Date.now(); endShownUntil = 0; schedule(); }
  }, { passive: true });
  loadSettings();
})();
