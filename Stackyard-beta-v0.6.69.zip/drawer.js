/* Dashboard drawer (Anna, 2026-10-27): Substack's dashboard (/publish) has no left nav. Resting the
   pointer on the left edge slides out Stackyard's copy of Substack's rail, the same edge drawer the
   Stackyard page uses. Drawn from the copy nav.js keeps in storage, at Substack's own sizes and
   positions, inside a shadow root so Substack's CSS and ours never meet. */
(() => {
  const onDashboard = () => /^\/publish(\/|$)/.test(location.pathname);
  if (!onDashboard() || document.getElementById("sy-dashboard-drawer")) return;
  const U = globalThis.SubstackVillages;
  const STACKYARD = chrome.runtime.getURL("village.html");
  const ORANGE = "#ff6719";   // Create is always Substack's orange, whatever page the copy came from
  const safeHref = (u) => {
    try { const x = new URL(u); return x.protocol === "https:" && /(^|\.)substack\.com$/.test(x.hostname) ? x.href : ""; }
    catch { return ""; }
  };

  function styles(saved) {
    const width = saved.width > 40 && saved.width < 200 ? saved.width : 76;
    const fade = saved.iconOpacity > 0 && saved.iconOpacity < 1 ? `opacity: ${saved.iconOpacity};` : "";
    return `
      :host { all: initial; }
      .edge { position: fixed; left: 0; top: 0; width: 14px; height: 100vh; z-index: 2147483646; }
      .edge::after { content: ""; position: absolute; left: 3px; top: calc(50% - 24px); width: 3px; height: 48px; border-radius: 3px; background: rgba(0,0,0,.14); }
      .rail { position: fixed; left: 0; top: 0; z-index: 2147483647; height: 100vh; width: ${width}px; box-sizing: border-box; padding: 18px 0;
        display: flex; flex-direction: column; align-items: center; gap: 6px; background: #fff; border-right: 1px solid #e6e6e6;
        transform: translateX(-100%); transition: transform .22s ease, box-shadow .22s ease; font-family: -apple-system, system-ui, sans-serif; }
      .edge:hover + .rail, .rail:hover, .rail:focus-within { transform: none; box-shadow: 4px 0 18px rgba(0,0,0,.12); }
      a { display: grid; place-items: center; width: 56px; height: 56px; border-radius: 12px; color: ${saved.iconColor || "#5c5c5c"}; text-decoration: none; }
      a:hover, a:focus-visible { background: #f2f2f2; outline: none; }
      a.brand { margin-bottom: 10px; }
      a.create, a.create:hover, a.create:focus-visible { width: 48px; height: 48px; background: ${ORANGE}; color: #fff; }
      a.create:hover { filter: brightness(.95); }
      a.more { margin-top: auto; }
      svg { max-width: 40px; max-height: 40px; ${fade} }
      svg:not([width]) { width: 28px; height: 28px; }
      img { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; }
      img.sy { border-radius: 0; width: 30px; height: auto; }   /* as on Substack's rail and the Stackyard page */
      .rail.measured a { position: absolute; left: 50%; margin: 0; transform: translate(-50%, -50%); }
      .rail.measured a.more { transform: translate(-50%, 50%); }
      @media (prefers-color-scheme: dark) { .rail { background: #1a1a1a; border-color: #2e2e2e; } a:hover, a:focus-visible { background: #2a2a2a; } }`;
  }

  function stackyardLink() {
    const a = document.createElement("a"); a.href = STACKYARD; a.title = "Stackyard"; a.setAttribute("aria-label", "Stackyard");
    a.addEventListener("click", (event) => { event.preventDefault(); location.href = STACKYARD; });
    const img = document.createElement("img"); img.className = "sy"; img.src = chrome.runtime.getURL("icons/logo.svg"); img.alt = "";
    a.append(img);
    return a;
  }

  // One saved rail item as a link. Create, More and Dashboard are buttons on Substack whose menus only
  // exist there, so they send you to Substack with the button's name and nav.js presses it.
  function itemLink(item, index, items) {
    const href = item.href ? safeHref(item.href) : `https://substack.com/home#stackyard-open=${encodeURIComponent(item.label || "")}`;
    if (!href) return null;
    const a = document.createElement("a"); a.href = href; a.title = item.label || "";
    if (item.label) a.setAttribute("aria-label", item.label);
    if (index === 0) a.className = "brand";
    else if (item.accent && !item.href) a.className = "create";
    else if (!item.href && (/more|menu/i.test(item.label) || index === items.length - 1)) a.className = "more";
    if (Number.isFinite(item.y)) a.dataset.y = item.y;
    if (Number.isFinite(item.bottom)) a.dataset.bottom = item.bottom;
    const icon = item.svg && !(index > 0 && item.svg === items[0].svg) ? U.cleanSvg(item.svg) : null;
    if (icon) a.append(icon);
    else if (/^https:/.test(item.img || "")) { const img = document.createElement("img"); img.src = item.img; img.alt = ""; a.append(img); }
    else a.textContent = (item.label || "?").slice(0, 1);
    return a;
  }

  // Each item carries its centre (y) measured from the top of Substack's rail, More its distance from
  // the bottom, and Stackyard sits where nav.js saw it (stackyardY). Without those, a plain column.
  function placeLikeSubstack(rail, saved) {
    const kids = [...rail.children];
    if (kids.filter((a) => a.dataset.y).length <= 3) return;
    rail.classList.add("measured");
    for (const a of kids) {
      if (a.classList.contains("more") && a.dataset.bottom) { a.style.bottom = `${a.dataset.bottom}px`; continue; }
      const y = a.dataset.y ? Number(a.dataset.y) : a.title === "Stackyard" ? saved.stackyardY : null;
      if (Number.isFinite(y)) a.style.top = `${y}px`; else a.remove();
    }
  }

  function draw(saved) {
    const items = saved?.items;
    if (!Array.isArray(items) || !items.length) return;
    const rail = document.createElement("nav"); rail.className = "rail"; rail.setAttribute("aria-label", "Substack and Stackyard");
    let placed = false;
    items.forEach((item, index) => {
      const a = itemLink(item, index, items);
      if (a) rail.append(a);
      if (!placed && /search|explore/i.test(`${item.label} ${item.href}`)) { rail.append(stackyardLink()); placed = true; }
    });
    if (!placed) rail.insertBefore(stackyardLink(), rail.children[1] || null);
    placeLikeSubstack(rail, saved);

    const host = document.createElement("div"); host.id = "sy-dashboard-drawer";
    const style = document.createElement("style"); style.textContent = styles(saved);
    const edge = document.createElement("div"); edge.className = "edge"; edge.setAttribute("aria-hidden", "true");
    host.attachShadow({ mode: "open" }).append(style, edge, rail);
    document.documentElement.append(host);
    // Substack moves between pages without reloading; the drawer belongs to the dashboard only.
    window.navigation?.addEventListener("navigatesuccess", () => { host.hidden = !onDashboard(); });
  }

  chrome.storage.local.get("substackNav").then(({ substackNav }) => draw(substackNav)).catch(() => {});
})();
