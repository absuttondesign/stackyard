/* Shared, dependency-free matching helpers. */
(() => {
  const DEFAULTS = {
    enabled: false,
    newestFirst: false,
    mode: "people",
    includeReposts: true,
    focusMode: false,
    hideRail: false,
    sources: [
      { name: "Code Like A Girl Village", url: "https://codelikeagirl.substack.com/recommendations", enabled: true },
      { name: "She Writes AI Village", url: "https://shewritesai.substack.com/recommendations", enabled: true }
    ],
    recommendations: [],
    refreshedAt: null
  };

  function normalizeName(value) {
    return String(value || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim()
      .replace(/\s+/g, " ");
  }

  function normalizeSourceUrl(input) {
    let value = String(input || "").trim();
    if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
    const url = new URL(value);
    if (url.protocol !== "https:" || !/(^|\.)substack\.com$/i.test(url.hostname)) {
      throw new Error("Use a Substack publication address, such as example.substack.com.");
    }
    if (url.hostname === "substack.com" || url.hostname === "www.substack.com") {
      throw new Error("Use a publication address, not the main Substack site.");
    }
    return `https://${url.hostname.toLowerCase()}/recommendations`;
  }

  function hostname(input) {
    try { return new URL(input).hostname.toLowerCase().replace(/^www\./, ""); }
    catch { return ""; }
  }

  function parseRecommendationHtml(html, sourceUrl, parser = new DOMParser()) {
    const doc = parser.parseFromString(html, "text/html");
    const heading = [...doc.querySelectorAll("h1,h2,h3")]
      .find((element) => /recommended by/i.test(element.textContent || ""));
    if (!heading) throw new Error("No public recommendations list found on this page.");

    const sourceHost = hostname(sourceUrl);
    const entries = new Map();
    for (const link of doc.querySelectorAll("a[href]")) {
      if (!(heading.compareDocumentPosition(link) & 4)) continue;
      const href = link.getAttribute("href");
      let url;
      try { url = new URL(href, sourceUrl); } catch { continue; }
      const host = hostname(url.href);
      if (!host || host === sourceHost || host === "substack.com" || host.endsWith(".substack.com") && host === "www.substack.com") continue;
      if (!/^https?:$/.test(url.protocol)) continue;
      const label = (link.textContent || "").replace(/\s+/g, " ").trim();
      if (!label || /^(subscribe|privacy|terms|start your substack|get the app)$/i.test(label)) continue;
      // The public list renders each recommendation next to its Subscribe control.
      const nearby = link.parentElement?.parentElement?.textContent || "";
      if (!/subscribe/i.test(nearby)) continue;
      const parts = label.match(/^(.*?)\s+By\s+(.+)$/i);
      const publication = (parts?.[1] || label).trim();
      const author = (parts?.[2] || "").trim();
      entries.set(host, { host, publication, author, source: sourceHost });
    }
    if (!entries.size) throw new Error("The recommendations page loaded, but its entries could not be read.");
    return [...entries.values()];
  }

  function uniqueRecommendations(entries) {
    const map = new Map();
    for (const entry of entries) {
      if (!entry.host) continue;
      const old = map.get(entry.host);
      if (old) {
        old.sources = [...new Set([...old.sources, ...(entry.sources || [entry.source])])];
        old.hosts = [...new Set([...old.hosts, ...(entry.hosts || [entry.host])])];
        if (!old.author && entry.author) old.author = entry.author;
      } else {
        map.set(entry.host, { ...entry, sources: entry.sources || [entry.source], hosts: entry.hosts || [entry.host] });
      }
    }
    return [...map.values()];
  }

  const RECOMMENDATIONS_PAGE_SIZE = 50;

  function recommendingPublicationId(html) {
    // The public /recommendations page embeds its own id inside the escaped _preloads JSON.
    const match = String(html || "").match(/recommending_publication_id\\?":(\d+)/);
    return match ? Number(match[1]) : null;
  }

  function publicationHosts(publication) {
    const hosts = [];
    if (publication?.subdomain) hosts.push(`${String(publication.subdomain).toLowerCase()}.substack.com`);
    const custom = hostname(`https://${publication?.custom_domain || ""}`);
    if (custom && !hosts.includes(custom)) hosts.push(custom);
    return hosts;
  }

  function entriesFromApi(items, sourceUrl) {
    const sourceHost = hostname(sourceUrl);
    const entries = [];
    for (const item of items || []) {
      const publication = item?.recommendedPublication;
      const hosts = publicationHosts(publication);
      if (!hosts.length) continue;
      entries.push({ host: hosts[0], hosts, publication: String(publication.name || "").trim(),
        author: String(publication.author?.name || "").trim(), source: sourceHost,
        // The writer's Substack user id: the key to their public Notes.
        authorId: Number(publication.author?.id || publication.author_id || publication.primary_user_id) || null });
    }
    return entries;
  }

  async function fetchAllRecommendations(sourceUrl, publicationId, fetcher = globalThis.fetch, listId = null) {
    // Substack serves the public list 50 at a time; the page HTML only embeds the first page.
    // With a list id it returns only that Substack List's members (same item shape).
    const origin = new URL(sourceUrl).origin;
    const filter = listId === null || listId === undefined ? "" : `list_id=${encodeURIComponent(listId)}&`;
    const all = [];
    for (let offset = 0; offset < 5000; offset += RECOMMENDATIONS_PAGE_SIZE) {
      const response = await fetcher(`${origin}/api/v1/recommendations/from/${publicationId}?${filter}offset=${offset}`, { credentials: "omit" });
      if (!response.ok) throw new Error(`HTTP ${response.status} while reading page ${offset / RECOMMENDATIONS_PAGE_SIZE + 1}`);
      const page = await response.json();
      if (!Array.isArray(page)) throw new Error("Unexpected recommendations response.");
      all.push(...page);
      if (page.length < RECOMMENDATIONS_PAGE_SIZE) break;
    }
    return all;
  }

  // ── Substack Lists (v0.6.70, Anna 2026-10-31: "now that Substack launched lists") ──────────
  // A List is a filtered view of a publication's recommendations: the same API with ?list_id=.
  // Shapes found 10/29 (Castle App/Plumbing/agent-queue/reviews/substack-lists-check.md):
  //   substack.com/@handle/lists/<id>        client-rendered; resolve through the public API
  //   <sub>.substack.com/lists/<slug-or-id>  page preloads carry pub.id + recommendationList.id
  //   <custom domain>/lists/<slug-or-id>     same page; needs the site allowed (no CORS headers)
  // Reading a list's members always goes to substack.com, so refreshes need no custom domain.
  const LIST_API = "https://substack.com";

  function parseListUrl(input) {
    // A List link → { kind, host, ref, url, handle?, customDomain }, or null for anything else.
    let value = String(input || "").trim();
    if (!value) return null;
    if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
    let url;
    try { url = new URL(value); } catch { return null; }
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    const host = url.hostname.toLowerCase();
    const bare = host.replace(/^www\./, "");
    const path = url.pathname.replace(/\/+$/, "");
    if (bare === "substack.com") {
      const m = path.match(/^\/@([A-Za-z0-9_.-]+)\/lists\/([A-Za-z0-9_-]+)$/);
      if (!m) return null;
      const handle = m[1].toLowerCase(), ref = m[2].toLowerCase();
      return { kind: "handle", host: "substack.com", handle, ref, url: `https://substack.com/@${handle}/lists/${ref}`, customDomain: false };
    }
    const m = path.match(/^\/lists\/([A-Za-z0-9_-]+)$/);
    if (!m) return null;
    const ref = m[1].toLowerCase();
    return { kind: "page", host, ref, url: `https://${host}/lists/${ref}`, customDomain: !/\.substack\.com$/.test(host) };
  }

  function isListSource(source) {
    const url = typeof source === "string" ? source : source?.url;
    try { return /\/lists\/[^/]+\/?$/.test(new URL(url).pathname); } catch { return false; }
  }

  function sourceKey(source) {
    // A haystack's id. A publication's is its host (unchanged since v0.1, so saved data still
    // matches); a List's is host + path, so jasmi.news/lists/ai never collides with jasmi.news.
    const url = typeof source === "string" ? source : source?.url;
    if (!isListSource(url)) return hostname(url);
    const parsed = new URL(url);
    return `${hostname(url)}${parsed.pathname.toLowerCase().replace(/\/+$/, "")}`;
  }

  function parsePreloads(html) {
    // Substack pages embed their data two ways: the newer <script id="preloads-json"> with plain
    // JSON (list pages, 2026-10), and the older window._preloads = JSON.parse("…escaped…").
    const text = String(html || "");
    const tag = text.match(/<script\b[^>]*\bid=["']preloads-json["'][^>]*>([\s\S]*?)<\/script>/i);
    if (tag) { try { return JSON.parse(tag[1]); } catch { /* fall through to the old form */ } }
    const old = text.match(/window\._preloads\s*=\s*JSON\.parse\(("(?:[^"\\]|\\.)*")\)/);
    if (old) { try { return JSON.parse(JSON.parse(old[1])); } catch { /* unreadable */ } }
    return null;
  }

  async function getJson(url, fetcher) {
    const response = await fetcher(url, { credentials: "omit" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  async function findList(publicationId, ref, fetcher = globalThis.fetch) {
    // The publication's public lists; match by id or slug. null when it isn't there (private,
    // removed, or never public). An unknown list id on the members call is an empty 200, not a 404.
    const data = await getJson(`${LIST_API}/api/v1/lists/${publicationId}`, fetcher);
    const key = String(ref).toLowerCase();
    return (data?.lists || []).find((list) => list && list.id !== 0 &&
      (String(list.id) === key || String(list.slug || "").toLowerCase() === key)) || null;
  }

  const LIST_NOT_PUBLIC = "That list isn't public, or it has been removed.";

  async function resolveList(link, fetcher = globalThis.fetch) {
    // A parsed List link → { publicationId, listId, listName, itemCount, theme }. No login.
    let publicationIds = [], ref = link.ref, theme = null;
    if (link.kind === "handle") {
      // The @handle page is client-rendered: its HTML has no list. The writer's public profile
      // names their publications; the list belongs to one of them (usually the primary).
      let profile;
      try { profile = await getJson(`${LIST_API}/api/v1/user/${encodeURIComponent(link.handle)}/public_profile`, fetcher); }
      catch { throw new Error(`Couldn't find @${link.handle} on Substack.`); }
      publicationIds = [profile?.primaryPublication?.id, ...(profile?.publicationUsers || []).map((pu) => pu?.publication?.id)];
    } else {
      // redirect: "manual" on a .substack.com address: a publication with its own domain redirects
      // there, which the extension can't read unless that site is allowed. Say so plainly.
      const response = await fetcher(link.url, { credentials: "omit", redirect: link.customDomain ? "follow" : "manual" });
      if (response.type === "opaqueredirect") {
        throw new Error("This publication has its own web address. Open the list, then paste the address from your browser's bar.");
      }
      if (response.status === 404) throw new Error(LIST_NOT_PUBLIC);
      if (!response.ok) throw new Error(`HTTP ${response.status} while opening the list.`);
      const html = await response.text();
      const preloads = parsePreloads(html);
      publicationIds = [preloads?.pub?.id || recommendingPublicationId(html)];
      if (preloads?.recommendationList?.id) ref = String(preloads.recommendationList.id);
      theme = parseTheme(html);
    }
    publicationIds = [...new Set(publicationIds.map(Number).filter((id) => id > 0))];
    if (!publicationIds.length) throw new Error("Couldn't read that list's page.");
    for (const publicationId of publicationIds) {
      const list = await findList(publicationId, ref, fetcher);
      if (list) return { publicationId, listId: Number(list.id), listName: String(list.name || "").trim() || "Substack List",
        itemCount: Number(list.item_count) || 0, theme };
    }
    throw new Error(LIST_NOT_PUBLIC);
  }

  async function fetchListEntries(source, fetcher = globalThis.fetch) {
    // A List haystack's members, read through the same parser as a publication's recommendations.
    // Each entry's source is the list's key, so dedupe and "which haystack" work as for any source.
    const items = await fetchAllRecommendations(LIST_API, source.publicationId, fetcher, source.listId);
    if (!items.length) throw new Error("That list is empty or private.");
    const key = sourceKey(source.url);
    return entriesFromApi(items, source.url).map((entry) => ({ ...entry, source: key }));
  }

  function ownEntry(html, sourceUrl, sourceName) {
    // The village's own publication belongs to the village too (Anna, 2026-09-29: Code Like A
    // Girl's own note was filtered out of the Code Like A Girl village). Its page names it in the
    // preloads ("author_name"); the village's display name is the fallback.
    const host = hostname(sourceUrl);
    const author = ((String(html || "").match(/author_name\\?":\\?"([^"\\]{1,120})/) || [])[1] || "").trim();
    const authorId = Number((String(html || "").match(/primary_user_id\\?":(\d+)/) || [])[1]) || null;
    const publication = String(sourceName || "").replace(/\s+Village$/i, "").trim() || host;
    return { host, hosts: [host], publication, author, source: host, authorId };
  }

  function villageRecommendations(settings, onlyEnabled = true) {
    // Every publication in the chosen villages: each village's recommendations PLUS the village's
    // own publication. The own entry is added here from the source list, so it counts even if the
    // lists were refreshed before this rule existed (Anna, 2026-09-29).
    // A List haystack is only its members: the curator's own publication isn't in it.
    const sources = (settings?.sources || []).filter((source) => !onlyEnabled || source.enabled);
    const keys = new Set(sources.map((source) => sourceKey(source.url)));
    const stored = (settings?.recommendations || []).filter((item) =>
      (item.sources || [item.source]).some((source) => keys.has(source)));
    const own = sources.filter((source) => !isListSource(source)).map((source) => stored.find((item) => item.host === hostname(source.url) && (item.sources || []).includes(item.host))
      || { ...ownEntry("", source.url, source.name), authorId: source.authorId || null });
    return uniqueRecommendations([...own, ...stored]);
  }

  function publicationName(html) {
    // The recommendations page title reads "Substacks recommended by <writer> | <Publication>".
    const title = (String(html || "").match(/og:title" content="([^"]{1,200})"/) || [])[1] || "";
    const name = title.includes(" | ") ? title.split(" | ").pop() : "";
    return name.replace(/&amp;/g, "&").replace(/&#39;|&#x27;/g, "'").replace(/&quot;/g, '"').trim();
  }

  // Each publication's recommendations are its haystack (Anna, 2026-09-29: "each publication
  // representing a haystack… finding things in the haystack just got a lot easier"). Saved
  // names still end in " Village" (older installs); the display drops it.
  function displayName(source) {
    return String(source?.name || "").replace(/\s+Village$/i, "").trim() || hostname(source?.url || "");
  }
  function haystackOf(name) {
    return `${name}${/s$/i.test(name) ? "’" : "’s"} haystack`;
  }

  function autoNamed(source) {
    // Villages added from an address get a placeholder name ("thecarrierfile Village").
    if (isListSource(source)) return false;
    const sub = hostname(source?.url || "").split(".")[0];
    return String(source?.name || "") === `${sub.replace(/[-_]/g, " ")} Village`;
  }

  async function fetchVillageLists(sources, fetcher = globalThis.fetch) {
    // Read each village's public recommendations page and full list. Returns every entry (the
    // village's own publication first), the page's theme and author id per village, and errors.
    const entries = [], errors = [], extras = new Map();
    for (const source of sources) {
      try {
        if (isListSource(source)) {
          // Stored ids → straight to substack.com. The list's current name comes from the same
          // public lists call, and follows the list unless the reader renamed it.
          let ids = { publicationId: source.publicationId, listId: source.listId };
          if (!ids.publicationId || ids.listId === undefined || ids.listId === null) {
            const link = parseListUrl(source.url);
            if (!link) throw new Error("Not a Substack List link.");
            ids = await resolveList(link, fetcher);
          }
          const list = await findList(ids.publicationId, ids.listId, fetcher);
          if (!list) throw new Error(LIST_NOT_PUBLIC);
          const listName = String(list.name || "").trim() || source.listName || source.name;
          const live = { ...source, publicationId: ids.publicationId, listId: Number(list.id) };
          entries.push(...await fetchListEntries(live, fetcher));
          extras.set(source.url, { publicationId: live.publicationId, listId: live.listId, listName,
            ...(!source.renamed && listName !== source.name ? { name: listName } : {}) });
          continue;
        }
        const response = await fetcher(source.url, { credentials: "omit" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const html = await response.text();
        const realName = publicationName(html);
        const name = autoNamed(source) && realName ? `${realName} Village` : source.name;
        const own = ownEntry(html, source.url, name);
        extras.set(source.url, { theme: parseTheme(html), authorId: own.authorId, ...(name !== source.name ? { name } : {}) });
        const publicationId = recommendingPublicationId(html);
        // Full list via the paginated public API (50 per page); the HTML only carries the first 50.
        const list = publicationId
          ? entriesFromApi(await fetchAllRecommendations(source.url, publicationId, fetcher), source.url)
          : parseRecommendationHtml(html, source.url);
        if (!list.length) throw new Error("No recommendations found.");
        entries.push(own, ...list);
      } catch (error) { errors.push(`${source.name}: ${error.message}`); }
    }
    return { entries, errors, extras };
  }

  function noteFromItem(item, entry) {
    // One item of a writer's public profile feed → a Note for the Village feed, or null.
    // Only the writer's own original Notes: restacks and other people's notes are skipped.
    const comment = item?.comment;
    if (!comment || item.context?.type !== "note" || !comment.id || !comment.date) return null;
    if (entry.authorId && comment.user_id !== entry.authorId) return null;
    const attachments = Array.isArray(comment.attachments) ? comment.attachments : [];
    const image = attachments.find((a) => a?.type === "image" && /^https:\/\//.test(a.imageUrl || ""))?.imageUrl || "";
    const linked = attachments.find((a) => a?.type === "post" && a.post);
    const handle = String(comment.handle || "").replace(/[^a-z0-9_.-]/gi, "");
    return {
      kind: "note",
      url: handle ? `https://substack.com/@${handle}/note/c-${comment.id}` : `https://substack.com/note/c-${comment.id}`,
      date: comment.date,
      author: String(comment.name || entry.author || "").trim(),
      publication: entry.publication || "",
      host: entry.host || "",
      body: String(comment.body || "").replace(/\n{3,}/g, "\n\n").trim(),
      image,
      linkedTitle: linked ? String(linked.post.title || "").trim() : "",
      linkedPublication: linked ? String(linked.publication?.name || "").trim() : "",
      likes: Number(comment.reaction_count) || 0,
      sources: entry.sources || [entry.source]
    };
  }

  function isFollowingUrl(url) {
    try {
      const parsed = new URL(url);
      return /(^|\.)substack\.com$/.test(parsed.hostname) &&
        (parsed.pathname.replace(/\/$/, "") === "/home/following" ||
         parsed.pathname.replace(/\/$/, "") === "/following" ||
         (parsed.pathname === "/home" && parsed.searchParams.get("feed") === "following"));
    } catch { return false; }
  }

  function isFollowingContext(url, selectedFeed) {
    if (isFollowingUrl(url)) return true;
    try {
      const parsed = new URL(url);
      return /(^|\.)substack\.com$/.test(parsed.hostname) &&
        (parsed.pathname === "/" || parsed.pathname === "/home") &&
        normalizeName(selectedFeed) === "following";
    } catch { return false; }
  }

  function isHomeFeedUrl(url) {
    // The Home feed lives under a few paths depending on which tab is selected (For you,
    // Following) and how Substack routes it; match the family, not an exact list.
    try {
      const parsed = new URL(url);
      if (!/^(www\.)?substack\.com$/.test(parsed.hostname)) return false;
      const path = parsed.pathname.replace(/\/$/, "") || "/";
      // A post or note opened from Home keeps Home's address (/home/post/p-123): that's a reader,
      // not the feed, and the haystack loader showed up over it (Anna, 2026-10-10).
      if (/\/(post|p|note)(\/|$)|\/c-\d+/.test(path)) return false;
      return path === "/" || /^\/(home|following|notes|feed)(\/|$)/.test(path);
    } catch { return false; }
  }

  function reactionHeader(card) {
    for (const element of card.querySelectorAll?.("*") || []) {
      const text = (element.textContent || "").replace(/\s+/g, " ").trim();
      if (text.length > 0 && text.length <= 120 && /\b(liked|restacked|reposted)$/i.test(text)) return text;
    }
    return "";
  }

  function cardMatches(card, recommendations, mode, includeReposts) {
    // Everything in the Home feed is a Note in practice (Anna, 2026-09-23): a "post" card is a
    // Note carrying a link to the post. So publication mode = any card whose post link
    // (a /p/ URL) points at a recommended publication, whatever the card calls itself.
    const kind = card.getAttribute?.("aria-label");
    if (kind === "Chat") return false;
    const text = (card.innerText || card.textContent || "").slice(0, 350);
    const repost = /\b(restacked|reposted|restack)\b/i.test(text);
    if (repost && !includeReposts) return false;
    // "Jane Doe and Sam Lee liked" / "Pat Kim restacked": the header names
    // who reacted, not who wrote. Links whose label appears in that header line don't count —
    // a villager liking a stranger's note is not the villager's note. (Anna, 2026-09-23.)
    // Find the header from the DOM, not innerText: a hidden card (display:none) has no innerText,
    // and Substack fills cards in after first render, so the header must be readable either way.
    // It is the first short element whose text ends in liked / restacked / reposted.
    const header = reactionHeader(card);
    const links = [...card.querySelectorAll("a[href]")].slice(0, 20)
      .filter((link) => !header || !header.includes((link.textContent || "").trim()) || !(link.textContent || "").trim());
    // People mode is about WHO WROTE the card, so it only looks at the byline: the first few links
    // (avatar, name, timestamp) once the reaction header is excluded. A villager mentioned in the
    // body, or a villager's post quoted inside someone else's note, does not make it theirs.
    // Publication mode keeps every link: it is defined as "notes that link to village posts".
    const byline = links.slice(0, 3);
    const linkHosts = new Set(byline.map((link) => hostname(link.href)).filter(Boolean));
    const postHosts = new Set(links.filter((link) => {
      try { return /^\/p\//.test(new URL(link.href).pathname); }
      catch { return false; }
    }).map((link) => hostname(link.href)));
    const linkLabels = new Set(byline.map((link) => normalizeName(link.textContent)).filter(Boolean));

    for (const entry of recommendations) {
      const hosts = entry.hosts || [entry.host];
      if (mode === "publications") {
        if (hosts.some((host) => postHosts.has(host))) return true;
        continue;
      }
      if (hosts.some((host) => linkHosts.has(host))) return true;
      if (mode === "people") {
        // A byline can be the writer's name or, for a publication's own notes, the publication's.
        for (const name of [entry.author, entry.publication].map(normalizeName).filter(Boolean)) {
          if ([...linkLabels].some((label) => label === name || label.startsWith(`${name} `))) return true;
        }
      }
    }
    return false;
  }

  function reactionHeaderElement(card) {
    for (const element of card.querySelectorAll?.("*") || []) {
      const text = (element.textContent || "").replace(/\s+/g, " ").trim();
      if (text.length > 0 && text.length <= 120 && /\b(liked|restacked|reposted)$/i.test(text)) return element;
    }
    return null;
  }

  const CARD_SELECTOR = '[aria-label="Note"],[aria-label="Post"]';

  function cardTimestamp(card) {
    // Sort on when the ORIGINAL Note or Post was published, nothing else (Anna, 2026-09-29):
    // - skip anything inside the "X liked / restacked" header: that is when someone reacted,
    // - skip anything inside a quoted Note/Post nested in this card,
    // - skip anything inside the action bar (like / restack / reply buttons and their counts).
    // The first dated element left is the card's own byline timestamp.
    const header = reactionHeaderElement(card);
    for (const element of card.querySelectorAll("time[datetime],a[title]")) {
      if (header && header !== card && header.contains?.(element)) continue;
      const owner = element.closest?.(CARD_SELECTOR);
      if (owner && owner !== card && card.contains?.(owner)) continue;
      if (element.closest?.('button,[role="button"],[role="toolbar"],[aria-label*="like" i],[aria-label*="restack" i]')) continue;
      const value = element.getAttribute("datetime") || element.getAttribute("title");
      const timestamp = Date.parse(value || "");
      if (Number.isFinite(timestamp)) return timestamp;
    }
    return null;
  }

  function cardKey(card) {
    // A stable id for the Note/Post a card shows, so its sort position can be frozen even when
    // Substack re-renders the card (e.g. after Anna likes it). The permalink is the first link
    // to a note (/note/c-123) or a post (/p/slug) outside any quoted card.
    for (const link of card.querySelectorAll?.("a[href]") || []) {
      const owner = link.closest?.(CARD_SELECTOR);
      if (owner && owner !== card && card.contains?.(owner)) continue;
      let url;
      try { url = new URL(link.href); } catch { continue; }
      if (/\/note\/c-\d+|\/p\/[^/]+/.test(url.pathname)) return `${url.hostname}${url.pathname}`;
    }
    return null;
  }

  function safeColor(value) {
    const color = String(value || "").trim();
    return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(color) ? color : null;
  }

  function parseTheme(html) {
    // A publication's page carries its theme as CSS variables (--background_pop is its accent,
    // --web_bg_color its page color) and its icon as <link rel="icon">. Read only those, and
    // only valid hex colors, so nothing from the page can inject style.
    const text = String(html || "");
    const variable = (name) => safeColor((text.match(new RegExp(`--${name}:\\s*([^;}\\s]+)`)) || [])[1]);
    const accent = variable("background_pop") || variable("color_theme_accent");
    if (!accent) return null;
    const icons = [...text.matchAll(/<link[^>]+rel="(?:icon|apple-touch-icon)"[^>]*>/g)].map((m) => m[0]);
    const pick = icons.find((tag) => /sizes="(48x48|32x32)"/.test(tag)) || icons.find((tag) => /image\/png/.test(tag)) || icons[0] || "";
    const href = (pick.match(/href="([^"]+)"/) || [])[1] || "";
    const icon = /^https:\/\//.test(href) ? href.replace(/&amp;/g, "&") : "";
    const bg = variable("web_bg_color") || variable("color_theme_bg_web");
    // Masthead (Anna, 2026-09-29): the publication's own wordmark and heading font, so the Village
    // feed looks like the publication's front page rather than a block of its accent color.
    // The wordmark comes from the page's own "pub" object — the page also lists other
    // publications, whose wordmarks can appear first.
    const unescaped = text.replace(/\\"/g, '"');
    const pubAt = unescaped.indexOf('"pub":{');
    const pub = pubAt >= 0 ? unescaped.slice(pubAt, pubAt + 20000) : "";
    const wide = (pub.match(/"logo_url_wide":"(https:\/\/[^"\s]+)"/) || [])[1] || "";
    const wordmark = /^https:\/\/(substackcdn\.com|substack-post-media\.s3\.amazonaws\.com|bucketeer-[\w-]+\.s3\.amazonaws\.com)\//.test(wide) ? wide : "";
    const fontName = (name) => ((text.match(new RegExp(`--${name}:\\s*'([^']{1,60})'`)) || [])[1] || "").replace(/[^A-Za-z0-9 ]/g, "").trim();
    return { version: 2, accent, bg: bg && bg.toLowerCase() !== "#ffffff" ? bg : null, pageColor: bg || "#ffffff",
      icon, wordmark, headingFont: fontName("font_family_headings_preset") };
  }

  // Substack's exact orange (v0.6.49, Anna: "make sure all the orange on the Stackyard is the
  // correct substack orange"). nav.js copies it from Substack's own Create button; every orange in
  // the popup and the Stackyard page reads --on, so set --on (and its hover and pale tint) from it.
  // Any CSS color works: on wide-gamut Macs Chrome reports it as color(display-p3 …), not rgb(…).
  function applySubstackOrange(substackNav, root = document.documentElement) {
    const color = (substackNav?.items || []).find((item) => item.accentColor)?.accentColor || "";
    if (!color || !CSS.supports("color", color)) return;
    root.style.setProperty("--on", color);
    root.style.setProperty("--on-hover", `color-mix(in srgb, ${color} 91%, black)`);
    if (!matchMedia("(prefers-color-scheme: dark)").matches) root.style.setProperty("--on-soft", `color-mix(in srgb, ${color} 10%, white)`);
  }

  // Substack's nav icons, copied as markup by nav.js, drawn again by the Stackyard page and the dashboard
  // drawer. Parsed as HTML (Substack's inline SVGs carry no xmlns; an XML parse leaves them invisible),
  // with scripts, foreignObject, event handlers and javascript: values removed.
  function cleanSvg(markup) {
    const svg = new DOMParser().parseFromString(markup || "", "text/html").body.firstElementChild;
    if (!svg || svg.nodeName.toLowerCase() !== "svg") return null;
    for (const el of [svg, ...svg.querySelectorAll("*")]) {
      if (/^(script|foreignObject)$/i.test(el.nodeName)) { el.remove(); continue; }
      for (const attr of [...el.attributes]) if (/^on/i.test(attr.name) || /javascript:/i.test(attr.value)) el.removeAttribute(attr.name);
    }
    return document.importNode(svg, true);
  }

  const api = { DEFAULTS, applySubstackOrange, cleanSvg, normalizeName, normalizeSourceUrl, hostname,
    parseRecommendationHtml, recommendingPublicationId, publicationHosts, entriesFromApi, fetchAllRecommendations,
    uniqueRecommendations, isFollowingUrl, isFollowingContext, isHomeFeedUrl, cardMatches, cardTimestamp,
    cardKey, parseTheme, safeColor, ownEntry, villageRecommendations, fetchVillageLists, noteFromItem,
    publicationName, autoNamed, displayName, haystackOf, parseListUrl, isListSource, sourceKey, parsePreloads,
    findList, resolveList, fetchListEntries };
  if (typeof module !== "undefined") module.exports = api;
  if (typeof globalThis !== "undefined") globalThis.SubstackVillages = api;
})();
