(() => {
  const U = globalThis.SubstackVillages;
  const $ = (id) => document.getElementById(id);
  let settings;

  let undoRemove = null;
  function setStatus(message, kind = "", action = "") {
    const status = $("status");
    status.textContent = message;
    status.className = `status ${kind}`;
    if (action && undoRemove) {
      const button = document.createElement("button"); button.type = "button"; button.className = "undo"; button.textContent = action;
      const run = undoRemove; undoRemove = null;
      button.addEventListener("click", run);
      status.append(" ", button);
    }
  }

  async function save(patch) {
    settings = { ...settings, ...patch };
    await chrome.storage.local.set(patch);
    render();
  }

  function countFor(source) {
    const key = U.sourceKey(source.url);
    return U.villageRecommendations({ sources: [source], recommendations: settings.recommendations }, false)
      .filter((item) => (item.sources || [item.source]).includes(key)).length;
  }

  function startRename(source, name) {
    // Click a haystack's name to rename it (any haystack, List or publication). Enter or leaving
    // the box saves; Escape cancels; an empty name keeps the old one.
    const input = document.createElement("input");
    input.className = "rename"; input.value = U.displayName(source); input.maxLength = 80;
    input.setAttribute("aria-label", `Rename ${U.displayName(source)}`);
    let done = false;
    const finish = (keep) => {
      if (done) return; done = true;
      const value = input.value.replace(/\s+/g, " ").trim();
      if (!keep || !value || value === U.displayName(source)) { render(); return; }
      save({ sources: settings.sources.map((item) => item.url === source.url ? { ...item, name: value, renamed: true } : item) });
    };
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") { event.preventDefault(); finish(true); }
      if (event.key === "Escape") { event.preventDefault(); finish(false); }
    });
    input.addEventListener("blur", () => finish(true));
    name.replaceWith(input); input.focus(); input.select();
  }

  function render() {
    // One switch: ON = haystacks only + newest first; OFF = Substack's feed as it is.
    // Storage keys are unchanged (enabled, newestFirst) and always move together.
    document.querySelector(`input[name="mode"][value="${settings.mode}"]`).checked = true;
    const on = settings.enabled;
    $("village-options").hidden = !on;
    $("power-hint").textContent = on ? "Showing your haystacks, newest first." : "Showing Substack's own feed.";
    $("enabled").checked = on;
    $("power").classList.toggle("is-on", on);
    $("power-state").textContent = on ? "ON" : "OFF";
    $("reposts").checked = settings.includeReposts;
    const focus = Boolean(settings.focusMode);
    $("focus").checked = focus;
    $("focus-power").classList.toggle("is-on", focus);
    $("focus-state").textContent = focus ? "ON" : "OFF";
    $("hide-rail").checked = Boolean(settings.hideRail);
    $("focus-hint").textContent = focus ? "Preserving your attention: no unread badges." : "Hide the unread badges that pull you in.";
    const list = $("sources");
    list.replaceChildren();
    for (const source of settings.sources) {
      const row = document.createElement("li");
      row.className = `source${source.enabled ? "" : " is-disabled"}`;
      const toggle = document.createElement("input"); toggle.type = "checkbox"; toggle.checked = source.enabled;
      toggle.className = "haystack-check";
      toggle.setAttribute("aria-label", `Use ${source.name}`);
      toggle.addEventListener("change", () => save({ sources: settings.sources.map((item) =>
        item.url === source.url ? { ...item, enabled: toggle.checked } : item) }));
      const dot = document.createElement("span"); dot.className = "dot";
      dot.style.background = U.safeColor(source.theme?.accent) || "var(--text-faint)";
      const name = document.createElement("button"); name.type = "button"; name.className = "name";
      name.textContent = U.displayName(source); name.title = `${source.url} · click to rename`;
      name.addEventListener("click", () => startRename(source, name));
      if (U.isListSource(source)) { const tag = document.createElement("span"); tag.className = "list-tag"; tag.textContent = "list"; name.append(tag); }
      const count = document.createElement("span"); count.className = "count";
      const n = countFor(source); count.textContent = n ? String(n) : "–";
      count.title = `${n} ${U.isListSource(source) ? "publications in this list" : "recommended publications"}`;
      const remove = document.createElement("button"); remove.type = "button"; remove.className = "remove"; remove.textContent = "×";
      remove.setAttribute("aria-label", `Remove ${source.name}`);
      remove.addEventListener("click", async () => {
        const before = settings.sources;
        await save({ sources: settings.sources.filter((item) => item.url !== source.url) });
        undoRemove = () => save({ sources: before });
        setStatus(`Removed ${source.name}.`, "busy", "Undo");
      });
      row.append(toggle, dot, name, count, remove); list.append(row);
    }
    // A failed refresh used to vanish when the popup closed, so a blank feed had no visible cause.
    if (settings.lastRefreshError) setStatus(`Not updated: ${settings.lastRefreshError}`, "error");
    else if (!settings.refreshedAt) setStatus("Loading the haystacks…", "busy");
    else setStatus(`${U.villageRecommendations(settings).length} publications · updated ${new Date(settings.refreshedAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`);
  }

  async function refresh() {
    const button = $("refresh"); button.disabled = true;
    setStatus("Reading recommendation lists…", "busy");
    // Every village, ticked or not: a village's count is its list, not whether it's in use today.
    // (Reading only ticked ones dropped the others' lists — counts fell to 1. Anna, 2026-09-29.)
    const { entries: all, errors, extras } = await U.fetchVillageLists(settings.sources);
    if (all.length && !errors.length) {
      const sources = settings.sources.map((item) => extras.has(item.url) ? { ...item, ...extras.get(item.url) } : item);
      await save({ sources, recommendations: U.uniqueRecommendations(all), refreshedAt: new Date().toISOString(), lastRefreshError: "" });
    } else if (errors.length) {
      // A partial fetch is not a refresh: keep the previous lists and say what failed (and keep
      // saying it next time the popup opens).
      await save({ lastRefreshError: errors.join(" · ") });
    } else setStatus("Add a haystack first.", "error");
    button.disabled = false;
  }

  $("enabled").addEventListener("change", (event) =>
    save({ enabled: event.target.checked, newestFirst: event.target.checked }));
  $("focus").addEventListener("change", (event) => save({ focusMode: event.target.checked }));
  $("hide-rail").addEventListener("change", (event) => save({ hideRail: event.target.checked }));
  $("reposts").addEventListener("change", (event) => save({ includeReposts: event.target.checked }));
  document.querySelectorAll('input[name="mode"]').forEach((input) =>
    input.addEventListener("change", () => save({ mode: input.value })));
  $("refresh").addEventListener("click", refresh);
  // The feedback form fills in the version, so reports say which build they came from.
  $("report-link").href += `?v=${encodeURIComponent(chrome.runtime.getManifest().version)}`;
  // Links in an extension popup don't open on their own; open the studio site in a new tab.
  document.querySelectorAll("a[data-open]").forEach((link) => link.addEventListener("click", (event) => {
    event.preventDefault(); chrome.tabs.create({ url: link.href });
  }));
  $("open-village").addEventListener("click", () => chrome.tabs.create({ url: chrome.runtime.getURL("village.html") }));
  async function addList(link) {
    if (settings.sources.some((source) => U.sourceKey(source.url) === U.sourceKey(link.url))) throw new Error("That list is already listed.");
    setStatus("Reading the list…", "busy");
    const list = await U.resolveList(link);
    const source = { name: list.listName, url: link.url, enabled: true, publicationId: list.publicationId,
      listId: list.listId, listName: list.listName, theme: list.theme };
    await U.fetchListEntries(source);   // empty or private → a plain message, nothing saved
    await save({ sources: [...settings.sources, source], pendingListLink: "" });
    $("source-url").value = "";
    await refresh();
  }

  $("add-source").addEventListener("submit", async (event) => {
    event.preventDefault();
    const value = $("source-url").value;
    const link = U.parseListUrl(value);
    if (link) {
      try {
        if (link.customDomain) {
          // A List on a publication's own domain (jasmi.news/lists/ai) is read from that page once,
          // to learn which publication and list it is; that site has to be allowed first. Ask now,
          // inside the click (Chrome only shows its prompt then). Keep the link: if the popup
          // closes while Chrome asks, reopening it picks up where it left off.
          const origins = [`https://${link.host.replace(/^www\./, "")}/*`, `https://www.${link.host.replace(/^www\./, "")}/*`];
          chrome.storage.local.set({ pendingListLink: value });
          // request() resolves true straight away, with no prompt, when the site is already allowed.
          const granted = await chrome.permissions.request({ origins });
          if (!granted) { await save({ pendingListLink: "" }); throw new Error(`Stackyard needs to read ${link.host} once to find that list. Not allowed, so it wasn't added.`); }
        }
        await addList(link);
      } catch (error) { setStatus(error.message, "error"); }
      return;
    }
    try {
      const url = U.normalizeSourceUrl(value);
      if (settings.sources.some((source) => source.url === url)) throw new Error("That source is already listed.");
      const name = `${new URL(url).hostname.split(".")[0].replace(/[-_]/g, " ")} Village`;
      await save({ sources: [...settings.sources, { name, url, enabled: true }] });
      $("source-url").value = "";
      await refresh();
    } catch (error) { setStatus(error.message, "error"); }
  });

  chrome.storage.local.get(null).then(async (stored) => {
    settings = { ...U.DEFAULTS, ...stored };
    U.applySubstackOrange(stored.substackNav);
    if (!stored.sources) await chrome.storage.local.set({ sources: settings.sources });
    // v0.4 let the two keys disagree (ON + Everything = sort only). One switch now: they match.
    if (settings.newestFirst !== settings.enabled) {
      settings.newestFirst = settings.enabled;
      await chrome.storage.local.set({ newestFirst: settings.enabled });
    }
    render();
    // A List link whose site permission was being asked for when the popup closed: finish adding it.
    if (stored.pendingListLink) {
      $("source-url").value = stored.pendingListLink;
      const link = U.parseListUrl(stored.pendingListLink);
      const host = link?.host.replace(/^www\./, "");
      if (link && await chrome.permissions.contains({ origins: [`https://${host}/*`, `https://www.${host}/*`] })) {
        try { await addList(link); } catch (error) { setStatus(error.message, "error"); }
        return;
      }
      chrome.storage.local.set({ pendingListLink: "" });
    }
    // First run (or a list over a week old): load the haystacks without waiting for a click.
    // Dinah's first install never got a Refresh, so the filter ran with no lists and hid the
    // whole feed ("0 found in 878 checked", 2026-10-10).
    const age = settings.refreshedAt ? Date.now() - Date.parse(settings.refreshedAt) : Infinity;
    if (settings.sources.length && !(age < 7 * 24 * 60 * 60 * 1000)) refresh();
  });
})();
