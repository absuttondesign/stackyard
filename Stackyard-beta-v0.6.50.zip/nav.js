/* Stackyard ↔ Substack nav (v0.6.34, Anna 2026-10-12):
   1. Adds a Stackyard item to Substack's own left nav, cloned from one of Substack's nav items so it
      looks exactly like the rest (and changes with them). It opens the Stackyard in the same tab.
   2. Keeps a copy of Substack's real nav (links, labels, icons, her avatar) in storage, so the
      Stackyard page can draw an exact match of it instead of a lookalike. */
(() => {
  const MINE = "data-sv-stackyard-item";
  const HOST = 'a,button,[role="button"],[role="link"]';
  const STACKYARD = chrome.runtime.getURL("village.html");
  const label = (el) => (el.getAttribute("aria-label") || el.textContent || "").trim();
  const href = (el) => el.getAttribute("href") || "";

  function findNav() {
    const hosts = [...document.querySelectorAll(HOST)].filter((el) => !el.closest(`[${MINE}]`));
    const home = hosts.find((el) => /^home$/i.test(label(el)) || /^(https:\/\/substack\.com)?\/home\/?$/.test(href(el)));
    const other = hosts.find((el) => el !== home && /chat|inbox|subscriptions|activity/i.test(`${label(el)} ${href(el)}`));
    if (!home || !other) return null;
    let nav = null;
    for (let up = home.parentElement; up && up !== document.body; up = up.parentElement) {
      if (!up.contains(other)) continue;
      const box = up.getBoundingClientRect();
      if (box.width > 360) break;
      if (box.height >= window.innerHeight * 0.6) nav = up;
    }
    return nav;
  }

  // The top-level items of the nav, in order (an item = a link/button not inside another one).
  const itemsOf = (nav) => [...nav.querySelectorAll(HOST)]
    .filter((el) => !el.parentElement.closest(HOST) && !el.closest(`[${MINE}]`) && el.offsetParent !== null);

  // The block to clone/insert next to: the item's highest wrapper that holds nothing but it.
  function unitOf(item, nav) {
    let unit = item;
    while (unit.parentElement && unit.parentElement !== nav && unit.parentElement.querySelectorAll(HOST).length === 1) unit = unit.parentElement;
    return unit;
  }

  function addStackyard(nav) {
    if (nav.querySelector(`[${MINE}]`)) return;
    const items = itemsOf(nav);
    const model = items.find((el) => /search|explore/i.test(`${label(el)} ${href(el)}`)) || items.find((el) => /activity/i.test(`${label(el)} ${href(el)}`));
    if (!model || model.tagName !== "A") return;
    const unit = unitOf(model, nav);
    const copy = unit.cloneNode(true);
    copy.setAttribute(MINE, "");
    const link = copy.matches("a") ? copy : copy.querySelector("a");
    link.href = STACKYARD; link.removeAttribute("target"); link.removeAttribute("aria-current");
    link.setAttribute("aria-label", "Stackyard"); link.title = "Stackyard";
    const oldName = label(model);
    for (const node of [...copy.querySelectorAll("*")].flatMap((el) => [...el.childNodes]).filter((n) => n.nodeType === 3)) {
      if (node.textContent.trim() && node.textContent.trim() === oldName) node.textContent = "Stackyard";
    }
    const svg = copy.querySelector("svg");
    if (svg) {
      const size = model.querySelector("svg")?.getBoundingClientRect();
      const img = document.createElement("img");
      img.src = chrome.runtime.getURL("icons/logo.svg"); img.alt = "";
      img.style.cssText = `width:${Math.round((size?.width || 24) * 1.25)}px;height:auto;display:block`;
      svg.replaceWith(img);
    }
    link.addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); location.href = STACKYARD; }, true);
    unit.after(copy);
  }

  // Substack's nav icons point at shapes stored elsewhere on the page (<use href="#…">) and get their
  // colors from Substack's CSS, so a plain copy draws nothing outside Substack. Make each icon stand
  // alone: pull the referenced shapes in, and write the computed stroke/fill onto every shape.
  // Colors become currentColor (the Stackyard sets the grey), and a filled "you are here" icon is
  // drawn as its outline, so the copy doesn't depend on which Substack page it was taken from.
  const PAINT = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
  function standaloneSvg(svg, keepColor = false) {
    const copy = svg.cloneNode(true);
    for (const use of [...copy.querySelectorAll("use")]) {
      const ref = use.getAttribute("href") || use.getAttribute("xlink:href") || "";
      const source = ref.startsWith("#") ? document.getElementById(ref.slice(1)) : null;
      if (!source) { use.remove(); continue; }
      if (!copy.getAttribute("viewBox") && source.getAttribute("viewBox")) copy.setAttribute("viewBox", source.getAttribute("viewBox"));
      const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
      for (const child of source.childNodes) group.append(child.cloneNode(true));
      use.replaceWith(group);
    }
    const color = getComputedStyle(svg).color;
    const originals = [svg, ...svg.querySelectorAll("*")];
    const shapes = [copy, ...copy.querySelectorAll("*")];
    originals.forEach((el, i) => {
      const target = shapes[i]; if (!target || target.tagName !== el.tagName) return;
      const style = getComputedStyle(el);
      for (const prop of PAINT) target.setAttribute(prop, style.getPropertyValue(prop));
      const stroke = style.stroke, fill = style.fill;
      if (keepColor) { target.setAttribute("stroke", stroke); target.setAttribute("fill", fill); return; }
      target.setAttribute("stroke", stroke === "none" ? "none" : "currentColor");
      target.setAttribute("fill", fill === "none" || fill === "rgba(0, 0, 0, 0)" || fill === color || fill === stroke ? "none" : "currentColor");
    });
    // A shape with neither stroke nor fill (a solid glyph) keeps fill so it still shows.
    for (const shape of copy.querySelectorAll("path,circle,rect,polygon,polyline,line,ellipse")) {
      if (shape.getAttribute("stroke") === "none" && shape.getAttribute("fill") === "none") shape.setAttribute("fill", "currentColor");
    }
    copy.removeAttribute("class"); copy.removeAttribute("style");
    const box = svg.getBoundingClientRect();
    copy.setAttribute("width", Math.round(box.width) || 24); copy.setAttribute("height", Math.round(box.height) || 24);
    return copy.querySelector("path,circle,rect,polygon,polyline,line,ellipse") ? copy.outerHTML : "";
  }

  // v0.6.39 (Anna): the copy must not depend on which Substack page it was taken from, and should
  // carry Substack's exact numbers (icon grey, oranges, rail width, where each item sits).
  // - The current page's icon is drawn solid by Substack; skip it and keep that item's plain
  //   outline from another visit (none yet → the Stackyard's backup icon).
  // - y = each item's centre from the top of the rail; bottom = More's distance from the bottom.
  const path = (u) => { try { return new URL(u, location.origin).pathname.replace(/\/+$/, "") || "/"; } catch { return ""; } };
  const here = path(location.href);
  const isActive = (el) => el.getAttribute("aria-current") === "page" || el.getAttribute("aria-selected") === "true" ||
    (href(el) && (path(href(el)) === here || (here === "/" && path(href(el)) === "/home")));
  let outlines = null;   // label → outline svg, from earlier visits
  chrome.storage.local.get("substackNav").then(({ substackNav }) => {
    outlines = {};
    // Keyed by slot: the logo is "__logo". (v0.6.40 keyed by label only; Substack labels the logo
    // link "Home" too, so on the Home page the logo's svg filled Home's slot: Anna saw two logos and
    // no house. Drop any non-logo entry that is a copy of the logo.)
    const items = substackNav?.items || [];
    items.forEach((item, index) => {
      if (!item.svg || (index > 0 && item.svg === items[0]?.svg)) return;
      outlines[index === 0 ? "__logo" : item.label] = item.svg;
    });
  });

  let last = "";
  function snapshot(nav) {
    if (!outlines) return;   // wait until earlier outlines are loaded
    const top = nav.getBoundingClientRect().top, bottom = nav.getBoundingClientRect().bottom;
    let iconColor = "", iconOpacity = 1;
    const items = itemsOf(nav).map((el, index) => {
      const svg = el.querySelector("svg");
      const img = el.querySelector("img");
      const rawHref = href(el);
      const name = label(el).replace(/\s+/g, " ").slice(0, 40);
      const active = index > 0 && isActive(el);
      const own = svg && !active ? standaloneSvg(svg, index === 0) : "";
      const slot = index === 0 ? "__logo" : name;
      if (own) outlines[slot] = own;
      // The grey you see is the shape's stroke (Substack sets it in CSS), not the text color, which
      // is near-black (Anna, v0.6.39: "our icons are nearly black now"). Read the drawn stroke, and
      // the icon's opacity in case the grey comes from fading black.
      if (svg && !active && !iconColor && index > 0 && !el.querySelector("img")) {
        const shape = svg.querySelector("path,circle,rect,polyline,line") || svg;
        const style = getComputedStyle(shape);
        const paint = style.stroke && style.stroke !== "none" ? style.stroke : style.fill;
        const fade = Number(getComputedStyle(svg).opacity) * Number(getComputedStyle(el).opacity);
        iconColor = paint && paint !== "none" ? paint : getComputedStyle(svg).color;
        if (fade < 1) iconOpacity = fade;
      }
      const box = el.getBoundingClientRect();
      const bg = getComputedStyle(el).backgroundColor;
      const accent = /create|new post|write/i.test(name) || /rgb\(2[45]\d, (9\d|10\d|11\d), (1\d|2\d|3\d)\)/.test(bg);
      return {
        label: name,
        href: rawHref ? new URL(rawHref, location.origin).href : "",
        svg: outlines[slot] || "",
        img: img && !svg ? img.src : "",
        accent, accentColor: accent ? bg : "",
        logoColor: index === 0 && svg ? getComputedStyle(svg.querySelector("path") || svg).fill : "",
        y: Math.round(box.top + box.height / 2 - top),
        bottom: Math.round(bottom - (box.top + box.height / 2))
      };
    }).filter((item) => item.svg || item.img || item.label);
    // Where our Stackyard item sits on Substack (the items after it are measured with it in place).
    const mine = nav.querySelector(`[${MINE}]`);
    const mineBox = mine?.getBoundingClientRect();
    const meta = { width: Math.round(nav.getBoundingClientRect().width), iconColor, iconOpacity,
      stackyardY: mineBox ? Math.round(mineBox.top + mineBox.height / 2 - top) : null };
    const data = JSON.stringify([items, meta]);
    if (data === last || !items.length) return;
    last = data;
    chrome.storage.local.set({ substackNav: { items, ...meta, savedAt: new Date().toISOString() } });
  }

  // Arriving from the Stackyard's Dashboard or Create: press that Substack button once, then tidy
  // the address bar (v0.6.42).
  // A whole mouse press, not just "click": menus like Substack's Create open on pointer-down
  // (v0.6.44, Anna: "make sure the subpanel opens up after the jump").
  function press(el) {
    const box = el.getBoundingClientRect();
    const at = { bubbles: true, cancelable: true, view: window, button: 0, clientX: box.left + box.width / 2, clientY: box.top + box.height / 2 };
    el.dispatchEvent(new PointerEvent("pointerdown", { ...at, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mousedown", at));
    el.dispatchEvent(new PointerEvent("pointerup", { ...at, pointerType: "mouse", isPrimary: true }));
    el.dispatchEvent(new MouseEvent("mouseup", at));
    el.dispatchEvent(new MouseEvent("click", at));
  }
  const isOpen = (el) => el.getAttribute("aria-expanded") === "true" || Boolean(document.querySelector('[role="menu"]'));

  let opened = false;
  function openRequested(nav) {
    const match = location.hash.match(/stackyard-open=([^&]+)/);
    if (opened || !match) return;
    const wanted = decodeURIComponent(match[1]).toLowerCase();
    const target = itemsOf(nav).find((el) => label(el).replace(/\s+/g, " ").slice(0, 40).toLowerCase() === wanted);
    if (!target) return;
    opened = true;
    const pick = (location.hash.match(/pick=([^&]+)/) || [])[1];
    history.replaceState(null, "", location.pathname + location.search);
    setTimeout(() => {
      press(target);
      // If a menu-type button didn't open from the press, try a plain click once.
      setTimeout(() => { if (/create|new|write/i.test(wanted) && !isOpen(target)) target.click(); }, 400);
      if (!pick) return;
      // Then the item in Substack's Create menu, by its exact text.
      const want = decodeURIComponent(pick).toLowerCase();
      let tries = 0;
      const look = setInterval(() => {
        const choice = [...document.querySelectorAll('[role="menuitem"],[role="menu"] a,[role="menu"] button,a,button,div')]
          .find((el) => el.offsetParent !== null && el.textContent.trim().toLowerCase() === want && el.children.length <= 3);
        if (choice) { clearInterval(look); press(choice.closest('a,button,[role="menuitem"]') || choice); }
        else if (++tries > 30) clearInterval(look);
      }, 100);
    }, 300);
  }

  // The fine line down the right of the nav (v0.6.48, Anna): Substack draws it on Chat; give Home,
  // Subscriptions, Activity and the rest the same #e6e6e6 hairline the Stackyard uses. Skipped
  // where the nav already has a border (Chat), so it never doubles.
  const LINE = "data-sv-line";
  const lineStyle = document.createElement("style");
  lineStyle.textContent = `[${LINE}]{box-shadow:inset -1px 0 0 #e6e6e6!important}` +
    `@media (prefers-color-scheme: dark){[${LINE}]{box-shadow:inset -1px 0 0 #2e2e2e!important}}`;
  (document.head || document.documentElement).append(lineStyle);
  function addLine(nav) {
    const own = parseFloat(getComputedStyle(nav).borderRightWidth) > 0;
    const next = nav.nextElementSibling;
    const beside = next && parseFloat(getComputedStyle(next).borderLeftWidth) > 0;
    nav.toggleAttribute(LINE, !own && !beside && !location.pathname.startsWith("/chat"));
  }

  let timer = 0;
  const run = () => { timer = 0; const nav = findNav(); if (!nav) return; addStackyard(nav); addLine(nav); snapshot(nav); openRequested(nav); };
  new MutationObserver(() => { if (!timer) timer = setTimeout(run, 400); })
    .observe(document.documentElement, { childList: true, subtree: true });
  run();
})();
