/* Focus mode: hide Substack's unread badges — the orange numbers and dots on the left nav
   (Home, Inbox, Chat, Activity) — and the "(3)" in the tab title. Anna, 2026-10-12: "If I see a
   badge I want to click it." The counts are still there once you click in; like/reply counts on
   notes are left alone. "Hide the side menu" (v0.6.21) turns the left rail into a drawer that
   slides out when the mouse touches the left edge.
   Nothing is removed from the page: matches get an attribute, and one CSS rule hides them only while
   html[data-sv-focus="on"]. Turning the switch off shows everything again without a reload. */
(() => {
  const FOCUS = "data-sv-focus", MARK = "data-sv-hook";
  const NORAIL = "data-sv-norail", RAIL = "data-sv-rail", OPEN = "data-sv-rail-open";
  const NUM = /^\d[\d,.]*\s*[KkMm]?\+?$/;
  const NAV = /home|inbox|chat|activity|notification|message|unread|subscriptions|explore/i;
  const NAV_AREA = 'nav,[role="navigation"],aside,header';
  const HOST = 'a,button,[role="button"],[role="link"],[role="tab"]';

  // Arriving from the Stackyard's Dashboard button (v0.6.43, Anna: "the home and animation flashes
  // very quick before it goes to the dash"): keep the page blank until nav.js has pressed the button
  // and the page has moved on. Create opens its menu ON home, so that one stays visible.
  const opening = location.hash.match(/stackyard-open=([^&]+)/);
  // Create → Note opens a composer over the page, so keep that one visible; other picks move on.
  const pick = (location.hash.match(/pick=([^&]+)/) || [])[1] || "";
  const staysOnPage = /create|new|write/i.test(decodeURIComponent(opening?.[1] || "")) && (!pick || /^note$/i.test(decodeURIComponent(pick)));
  if (opening && !staysOnPage) {
    const cover = document.createElement("style");
    cover.textContent = "html{visibility:hidden!important;background:#fff!important}";
    (document.head || document.documentElement).append(cover);
    const start = location.href;
    const reveal = () => cover.remove();
    setTimeout(reveal, 4000);   // never leave her on a blank page
    const watch = setInterval(() => {
      if (location.pathname !== new URL(start).pathname) { clearInterval(watch); setTimeout(reveal, 150); }
    }, 100);
  }

  const style = document.createElement("style");
  style.textContent = `html[${FOCUS}="on"] [${MARK}]{display:none!important}` +
    // z-index stays modest (500): Substack's own popovers (More → Settings / Support / Sign out)
    // must draw ON TOP of the drawer; at max z the menu slid underneath it (Anna, 2026-10-12).
    // Hide the side menu (v0.6.21): the left rail becomes a drawer parked off-screen. Touching the
    // left edge (the strip) or tabbing into it slides it out; leaving it tucks it away again.
    `html[${NORAIL}="on"] [${RAIL}]{position:fixed!important;left:0!important;top:0!important;height:100vh!important;` +
    `z-index:500!important;background:var(--sv-rail-bg,#fff)!important;transform:translateX(-100%);` +
    `transition:transform .22s ease,box-shadow .22s ease!important}` +
    `html[${NORAIL}="on"][${OPEN}] [${RAIL}],html[${NORAIL}="on"] [${RAIL}]:hover,html[${NORAIL}="on"] [${RAIL}]:focus-within` +
    `{transform:none;box-shadow:4px 0 18px rgba(0,0,0,.12)}` +
    `.sv-rail-edge{display:none}` +
    `html[${NORAIL}="on"] .sv-rail-edge{display:block;position:fixed;left:0;top:0;width:14px;height:100vh;z-index:499}` +
    `html[${NORAIL}="on"] .sv-rail-edge::after{content:"";position:absolute;left:3px;top:calc(50% - 24px);width:3px;height:48px;` +
    `border-radius:3px;background:rgba(0,0,0,.14)}`;
  (document.head || document.documentElement).append(style);

  let on = false, railOff = false, timer = 0, rail = null, edge = null, closeTimer = 0, pinned = false;
  document.addEventListener("pointerdown", (event) => {
    if (!pinned || !rail || rail.contains(event.target)) return;
    setTimeout(() => {
      pinned = false;
      if (!rail.matches(":hover")) document.documentElement.removeAttribute(OPEN);
    }, 300);
  }, true);

  const labelOf = (el) => el ? `${el.getAttribute("aria-label") || ""} ${el.getAttribute("href") || ""} ${el.getAttribute("title") || ""} ${el.getAttribute("data-testid") || ""}` : "";

  // A badge sits inside a nav link: one labelled Chat/Inbox/Activity…, or any link in the nav rail.
  const isNavHost = (host) => Boolean(host) && (NAV.test(labelOf(host)) || Boolean(host.closest(NAV_AREA)));

  function isDot(el) {
    const box = el.getBoundingClientRect();
    if (!box.width || box.width > 14 || box.height > 14) return false;
    const bg = getComputedStyle(el).backgroundColor;
    return bg && bg !== "transparent" && !/rgba\(.*,\s*0\)$/.test(bg);
  }

  // The number usually sits in an orange circle; hide the circle, not just the digit. Climb while
  // the wrapper is still badge-sized and holds no icon.
  function badgeOf(el, host) {
    let badge = el;
    for (let up = el.parentElement; up && up !== host; up = up.parentElement) {
      const box = up.getBoundingClientRect();
      if (box.width > 28 || box.height > 28 || up.querySelector("svg,img")) break;
      badge = up;
    }
    return badge;
  }

  // The rail: the narrow, full-height column that holds the Home and Chat/Inbox/Activity links.
  function findRail() {
    const links = [...document.querySelectorAll(HOST)].filter((el) => NAV.test(labelOf(el)));
    const home = links.find((el) => /home/i.test(labelOf(el)));
    const other = links.find((el) => el !== home && /chat|inbox|activity|notification/i.test(labelOf(el)));
    if (!home || !other) return null;
    let found = null;
    for (let up = home.parentElement; up && up !== document.body; up = up.parentElement) {
      if (!up.contains(other)) continue;
      const box = up.getBoundingClientRect();
      if (box.width > 160) break;
      if (box.height >= window.innerHeight * 0.6) found = up;
    }
    return found;
  }

  function placeRail() {
    if (!railOff || !document.body) return;
    if (!rail || !rail.isConnected) {
      rail?.removeAttribute(RAIL);
      rail = findRail();
      if (!rail) return;
      const bg = getComputedStyle(document.body).backgroundColor;
      document.documentElement.style.setProperty("--sv-rail-bg", bg && !/rgba\(.*,\s*0\)$|transparent/.test(bg) ? bg : "#fff");
      rail.setAttribute(RAIL, "");
      // A click inside the drawer (e.g. "More" → Settings / Support / Sign out) pins it open: that
      // menu pops out beside the rail, and if the drawer tucked away when the mouse moved onto it,
      // the menu was left stranded half off-screen (Anna, 2026-10-12). It unpins on the next click
      // outside the drawer, once that click has done its job.
      rail.addEventListener("mouseleave", () => {
        clearTimeout(closeTimer);
        if (pinned) return;
        closeTimer = setTimeout(() => document.documentElement.removeAttribute(OPEN), 250);
      });
      rail.addEventListener("mouseenter", () => clearTimeout(closeTimer));
      rail.addEventListener("click", () => { pinned = true; clearTimeout(closeTimer); document.documentElement.setAttribute(OPEN, ""); });
    }
    if (!edge || !edge.isConnected) {
      edge = document.createElement("div");
      edge.className = "sv-rail-edge";
      edge.title = "Menu";
      edge.addEventListener("mouseenter", () => { clearTimeout(closeTimer); document.documentElement.setAttribute(OPEN, ""); });
      document.body.append(edge);
    }
  }

  function scan() {
    timer = 0;
    placeRail();
    if (!on || !document.body) return;
    for (const el of document.body.querySelectorAll("span,div,sup,b,strong,small,p")) {
      if (el.hasAttribute(MARK) || el.children.length) continue;
      const text = el.textContent.trim();
      const host = el.closest(HOST);
      if (!isNavHost(host)) continue;
      if (text && NUM.test(text)) badgeOf(el, host).setAttribute(MARK, "count");
      else if (!text && isDot(el)) el.setAttribute(MARK, "dot");
    }
    const title = document.title.replace(/^\(\d+\+?\)\s*/, "");
    if (title !== document.title) document.title = title;
  }

  const schedule = () => { if ((on || railOff) && !timer) timer = setTimeout(scan, 150); };
  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true, characterData: true });

  function apply(value) {
    on = Boolean(value);
    if (on) { document.documentElement.setAttribute(FOCUS, "on"); schedule(); }
    else document.documentElement.removeAttribute(FOCUS);
  }

  function applyRail(value) {
    railOff = Boolean(value);
    if (railOff) { document.documentElement.setAttribute(NORAIL, "on"); schedule(); }
    else document.documentElement.removeAttribute(NORAIL);
  }

  chrome.storage.local.get(["focusMode", "hideRail"]).then((stored) => { apply(stored.focusMode); applyRail(stored.hideRail); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if ("focusMode" in changes) apply(changes.focusMode.newValue);
    if ("hideRail" in changes) applyRail(changes.hideRail.newValue);
  });
  globalThis.__svFocus = { scan, apply, applyRail };   // for dev/focus-test.html
})();
